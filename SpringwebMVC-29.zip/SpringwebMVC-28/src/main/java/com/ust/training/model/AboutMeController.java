/**
 * Class : AboutMeController
 * 
 * Description: class contains getMyHobbies  which is annotated by @Controller
 * 
 * Date:14/10/2020
 * 
 */


package com.ust.training.model;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AboutMeController {
	
	@RequestMapping("/processForm")
	
	 public String process(@RequestParam("hobby") String theHobby, Model model) {
		
		// convert the data to all caps
		theHobby = theHobby.toUpperCase();
				
				// create the message
				String result = "Hey My Hobby is    " + theHobby;
				
				// add message to the model
				model.addAttribute("message", result);
				
		return "Myhobbies";
	}

}
