/**
 * ClassName:Students
 * 
 * Description:Student Model Class, 
 * 
 * Date:05-10-2020
 */

package com.ust.training;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Students {

	public static void main(String[] args) {

		// creating arrayList for students
		ArrayList<String> students = new ArrayList<String>();

		students.add("Vivek");
		students.add("Vijay");
		students.add("Ajith");
		students.add("Surya");

		System.out.println("Before Sorting");
		System.out.println("********************");

		// iterating with forEach loop
		for (String student : students)

			// printing student names
			System.out.println(student);

		System.out.println("After Sorting");

		System.out.println("********************");

		Collections.sort(students);

		for (String name : students) {

			System.out.println("Student Name is  " + name);
		}

	}
}
