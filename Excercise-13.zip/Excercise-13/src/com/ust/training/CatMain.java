/**
 * ClassName:CatMain
 * 
 * Description:Calling all the functionalities of Cat class
 * 
 * Date:05--10-2020
 * 
 */

package com.ust.training;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class CatMain {

	public static void main(String[] args) {

		// creating Arraylist of type Cat
		ArrayList<Cat> cats = new ArrayList<Cat>();

		Cat c1 = new Cat("Pussy1", 3);
		Cat c2 = new Cat("Pussy2", 2);
		Cat c3 = new Cat("Pussy3", 1);

		// adding Cat objects to ArrayList
		cats.add(c1);
		cats.add(c2);
		cats.add(c3);

		/* Before Sorting */

		Iterator<Cat> iterator = cats.iterator();

		System.out.println("Before Sorting ");

		System.out.println("********************");

		while (iterator.hasNext()) {

			Cat catitr = iterator.next();

			System.out.println("Cat  :" + catitr);
		}

		/* After Sorting */

		Collections.sort(cats);

		System.out.println("After Sorting");

		System.out.println("*****************");

		Iterator<Cat> iterator1 = cats.iterator();

		while (iterator1.hasNext()) {

			Cat catitrs = iterator1.next();

			System.out.println("Cat  :" + catitrs);
		}

	}

}
