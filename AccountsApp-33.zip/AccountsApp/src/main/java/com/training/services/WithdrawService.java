/**
  * Classname: WithdrawService
 * 
 * Description: this is a  class for WithdrawService  to access the outputs
 * 
 * Date:30/09/2020
 * 
 */



package com.training.services;


import com.training.Exception.InsufficiantMoneyException;
import com.training.model.CurrentAccount;
import com.training.model.FdAccount;
import com.training.model.LoanAccount;
import com.training.model.SbAccount;
import com.training.util.Icalculator;
import com.training.util.InterestCalculator;

/**
 *   class   with main method for WithdrawService  to access the outputs
 * 
 *
 */
public class WithdrawService {
/***
 * Main Method
 * @param args
 */
	public static void main(String[] args) {
		
		
		
		SbAccount scac = new SbAccount(4567,"Priyanka",10000,0.7f,30);
		
		try {
			scac.withdrawMoney(15000);
		} catch (InsufficiantMoneyException e) {
			
			System.out.println("Dear cutomer, " +e);
		}
		
		  
		
		
		
		
		
		
	}

}
