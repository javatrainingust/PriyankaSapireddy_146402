/**
 * Class Name: FdAccountController
 * 
 * Description: Class which is used give the http request to server by using @Controller and @RequestMapping
 * 
 * Date:15/10/2020
 */
package com.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.service.FdAccountService;


import com.training.model.FdAccount;
import com.training.model.SbAccount;

/**
 * FdAccountController Class which is used give the http request to server by using @Controller and @RequestMapping
 * @author sanga
 *
 */
@Controller
public class FdAccountController {
	
	@Autowired
	private FdAccountService service;
	
	/**
	 * 
	 * getAllAccounts method to get all FD Accounts
	 * @return to fdAccountList
	 */
	@RequestMapping("/fdaccounts")
	public String getAllfdAccounts(Model model){
		
		System.out.println("Inside controller getAllAccounts ");
		
		List<FdAccount> employeeList = service.getAllFdaAccountdetails();
		
		model.addAttribute("fdaccounts",employeeList );
		
		
		return "fdAccountList";
		

}
	@RequestMapping("/viewFdAccount")
	public String getaccount(@RequestParam("accountNo")String accountNo,Model model) {
		
		
		FdAccount pe = service.getFdAccountByAccountNumber(Integer.parseInt(accountNo));
		
		model.addAttribute("key", pe);
		
		
		return "viewFdAccount";
		
		
	}
	
	
	@RequestMapping("/deletefdAccount")
	public String deleteFdaccount(@RequestParam("accountNo")String accountNo,Model model) {
		
		
	 service.deleteFdAccount(Integer.parseInt(accountNo));
		
	
		
		
	 return  "redirect:/fdaccounts";
		
		
	}
}
