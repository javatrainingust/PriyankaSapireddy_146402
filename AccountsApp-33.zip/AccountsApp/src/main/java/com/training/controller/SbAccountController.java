/**
 * Class Name: SbAccountController
 * 
 * Description: Class which is used give the http request to server by using @Controller and @RequestMapping
 * 
 * Date:15/10/2020
 */

package com.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.model.CurrentAccount;
import com.training.model.SbAccount;
import com.training.service.CurrentAccountService;
 import com.training.service.SbAccountService;
/**
 *  Class which is used give the http request to server by using @Controller and @RequestMapping
 * @author sanga
 *
 */
 @Controller
public class SbAccountController {
	
	@Autowired
	private SbAccountService service;
	
	/**
	 *  getAllSbAccounts method to get all sb accounts  
	 *  
	 */
	@RequestMapping("/sbaccounts")
	public String getAllSbAccounts(Model model){
		
		System.out.println("Inside controller getAlSBAccounts ");
		
		List<SbAccount> employeeList = service.getAllSbAccountdetails();
		
		model.addAttribute("sbaccounts",employeeList );
		
		
		return "sbAccountList";
		
	}
	
	@RequestMapping("/viewSbAccount")
	public String getaccount(@RequestParam("accountNo")String accountNo,Model model) {
		
		
		SbAccount pe = service.getSbAccountByAccountNumber(Integer.parseInt(accountNo));
		
		model.addAttribute("key", pe);
		
		
		return "viewSbAccount";
		
		
	}
	@RequestMapping("/deletesbAccount")
	public String deleteSbaccount(@RequestParam("accountNo")String accountNo,Model model) {
		
		
		 service.deleteLoanAccount(Integer.parseInt(accountNo));
		
		
		
		
		return "redirect:/sbaccounts";
		
		
	}
}
