/**
 * ClassName:  SbBalanceComparator
 * 
 * Description:  for  comparing process 
 * 
 * Date-06-10-2020
 * */


package com.training.service;

import java.util.Comparator;

import com.training.model.CurrentAccount;
import com.training.model.SbAccount;
/**
 * Class  SbBalanceComparator  for comparing  the iutputs
 * 
 */
public class SbBalanceComparator  implements Comparator<SbAccount>  {

	
	public int compare(SbAccount one, SbAccount two) {
		// TODO Auto-generated method stub
		return (int) (one.getBalanceAmount()-two.getBalanceAmount());
	}

}
