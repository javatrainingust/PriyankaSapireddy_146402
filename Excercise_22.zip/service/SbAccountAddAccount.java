/**
 * ClassNAme: SbAccountAddAccount
 * 
 * Description: class for getting outputs
 * 
 * Date-08-10-2020
 */


package com.training.service;

import com.training.model.FdAccount;
import com.training.model.SbAccount;
/**
 *  class with main methods for getting outputs
 * @author sanga
 *
 */
public class SbAccountAddAccount {
/**
 * Main method
 * @param args
 */
	public static void main(String[] args) {
    
		SbAccountService service = new SbAccountService();
		
		service.addSbAccount(new SbAccount(1234, "Priyanka", 10000, 1.2f, 30));
		service.addSbAccount(new SbAccount(1235, "Sujatha", 90000, 1.4f, 40));
		service.addSbAccount(new SbAccount(1235, "Sujatha", 90000, 1.4f, 40));
		
		System.out.println("Printing all Accounts");	
		service.getAllSbAccountdetails();
		System.out.println("---------------------------------------------");	
		
        service.updateSbAccount(new SbAccount(1235, "Sujatha", 100000, 1.4f, 40));
		
		System.out.println("Printing all updated Accounts");	
		
		service.getAllSbAccountdetails();

	}

}
