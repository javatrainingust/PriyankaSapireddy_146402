package com.training.services;

import com.training.model.Account;
import com.training.model.FdAccount;
import com.training.model.SbAccount;
import com.training.util.InterestCalculator;

public class GenericService {
	
	public static void main(String[] args) {
	
	FdAccount fdacc = new FdAccount();
	
	  fdacc.setAccountNo("App123456634");
	  fdacc.setIfscCode("APP000561");
	  fdacc.setAccountHolderName("Priyanka");
	  fdacc.withDrawAmount(2000);
	  fdacc.autoRenewable(2);
	  fdacc.setRate(.5f);
	  fdacc.setTenure(1);
	  
	 
	SbAccount scac = new SbAccount();
		
	 
	  scac.setAccountNo("App123456634");
	  scac.setIfscCode("APP000561");
	  scac.setAccountHolderName("Priyanka");
	  scac.setRate(0.7f);
	  
	  
	  
	  Account[] a = {new Account(), fdacc,scac};
	  
	  InterestCalculator calculator = new InterestCalculator();
	  
	  for(Account account : a){
		  
		  account.calculateInterest(calculator);
		  if(account instanceof FdAccount) {
			  
			  FdAccount fdacc1 = new FdAccount();
			  
			  fdacc1.autoRenewable(2);
			  
			  
		  }
		  
		  
	  }
	  }
	  
	  
	  
	  
	  
	  
	

}
