package com.training.model;

public interface Renewable {
	
	public void autoRenewable(int ternure);

}
