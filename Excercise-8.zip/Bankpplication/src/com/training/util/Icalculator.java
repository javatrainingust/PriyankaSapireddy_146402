package com.training.util;

public interface Icalculator {
	
	public float calculateInterest(float rateOfInterest);
	
	public Float calculateInterest(float principle,float rate);

}
