package com.training.dataaccess;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.training.model.FdAccount;

public class FdAccountDAOImpl implements FdaaccountDao {
	
	List fdAccountList ;
	
	public FdAccountDAOImpl() {
		 
		fdAccountList =new ArrayList<FdAccount>();
		
		FdAccount fdac1 = new FdAccount(1234,"Priyanka",10000,4,0.2f);
		FdAccount fdac2 = new FdAccount(1235,"Sujatha",90000,4,0.3f);
		FdAccount fdac3 = new FdAccount(1236,"Karthika",130000,4,0.5f);
		
		fdAccountList.add(fdac1);
		fdAccountList.add(fdac2);
		fdAccountList.add(fdac3);
		
		
	}

	@Override
	public List<FdAccount> getAllFdaAccountdetails() {

	   return  fdAccountList;
	}

	@Override
	public FdAccount getFdAccountByAccountNumber(int accountNo) {
		
		FdAccount	fdAccount = null;
		
      Iterator<FdAccount> iterator = fdAccountList.iterator();
		
		while(iterator.hasNext()){
			
			FdAccount  pe = iterator.next();
			
			if(pe.getAccountNo()==accountNo){
				
				fdAccount=pe;
			}
			
			
		}
			
		
		return fdAccount;
	}
		

	@Override
	public void deleteFdAccount(int accountNo) {
		

		FdAccount	fdAccount = null;
		
         for(int i=0; i<fdAccountList.size(); i++){
			
         fdAccount =(FdAccount)fdAccountList.get(i);
			
			if( fdAccount.getAccountNo()==accountNo){
				
				fdAccountList.remove(i);
				
			}
			
		}		
		
		

	}


	}


