package com.training.dataaccess;

import java.util.List;

import com.training.model.FdAccount;

public interface FdaaccountDao {
	
	public List<FdAccount> getAllFdaAccountdetails();
 
	public FdAccount  getFdAccountByAccountNumber(int accountNo);
	
	public void deleteFdAccount(int accountNo);
	
	
}
