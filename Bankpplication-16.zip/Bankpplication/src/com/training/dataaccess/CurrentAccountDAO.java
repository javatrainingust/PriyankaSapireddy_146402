package com.training.dataaccess;

import java.util.List;

import com.training.model.CurrentAccount;


public interface CurrentAccountDAO {
	
	

	public List<CurrentAccount> getAllCurrentAccounttdetails();
 
	public CurrentAccount  getCurrentAccountByAccountNumber(int accountNo);
	
	public void deleteCurrentAccount(int accountNo);
	

}
