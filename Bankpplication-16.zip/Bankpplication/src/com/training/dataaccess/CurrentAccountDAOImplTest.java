package com.training.dataaccess;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.training.model.CurrentAccount;

class CurrentAccountDAOImplTest {

	CurrentAccountDAO dao = new CurrentAccountDAOImpl();
	CurrentAccount ca = new CurrentAccount();

	@Test
	void testGetAllCurrentAccounttdetails() {

		int expected = 3;
		List<CurrentAccount> actual = dao.getAllCurrentAccounttdetails();
		assertEquals(expected, actual.size());

	}

	@Test
	void testGetCurrentAccountByAccountNumber() {

		String expectedValue = "Priyanka";

		ca = dao.getCurrentAccountByAccountNumber(1234);

		String actualValue = ca.getAccountHolderName();

		assertEquals(expectedValue, actualValue);

	}

	@Test
	void testDeleteFdAccount() {

		int expectedSize = 2;
		dao.deleteCurrentAccount(1235);
		List<CurrentAccount> actual = dao.getAllCurrentAccounttdetails();
		assertEquals(expectedSize, actual.size());
	}

}
