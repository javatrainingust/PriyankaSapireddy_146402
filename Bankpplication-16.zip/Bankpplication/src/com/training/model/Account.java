/*
 * Classname: Account
 * 
 * Description: this is a base class for Account sub type
 * 
 * Date:30/09/2020
 * 
 */


package com.training.model;

import com.training.util.Icalculator;

public class Account {
	
	private int  accountNo;
	private String accountHolderName;
	private float balanceAmount;
	
	public int getAccountNo() {
		return accountNo;
	}
	
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	
	public String getAccountHolderName() {
		return accountHolderName;
	}
	
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	
	public float getBalanceAmount() {
		return balanceAmount;
	}
	
	
    public void  withDrawAmount( int withdrawAmount) {
    	
		this.balanceAmount =balanceAmount -withdrawAmount;
		System.out.println("Available balance in your savings account =" +this.balanceAmount);
	}
	    
	    
	  public void calculateInterest(Icalculator calculator) {
			
		 System.out.println("inside base class");
	  }
	  
	  @Override
		public String toString() {
			return "Account [accountNumber=" +  accountNo + ", accountHolderName=" + accountHolderName + "]";
		}
	    
	  /* constructor with non-parameters  */
	  public Account() {
		 super();
	  }
	  
	  /* constructor with  parameters */
	  public Account(int accountNo,String accountHolderName,float balanceAmount) {
		  super();
		  this.accountNo =accountNo;
		  this.accountHolderName=accountHolderName;
		  this.balanceAmount = balanceAmount;
	  }
	  
	  
	    
	   
	
}
