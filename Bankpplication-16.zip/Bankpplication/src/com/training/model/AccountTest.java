package com.training.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AccountTest {

	@Test
	void testWithDrawAmount() {
		int expected = 8000;
		Account a = new Account();
		a.withDrawAmount(2000);
		float actual = a.getBalanceAmount();
		assertEquals(expected,actual);
		
		
		
	}

}
