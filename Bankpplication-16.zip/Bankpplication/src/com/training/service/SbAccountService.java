package com.training.service;

import java.util.Iterator;
import java.util.List;

import com.training.dataaccess.LoanAccountDAO;
import com.training.dataaccess.LoanAccountDAOImpl;
import com.training.dataaccess.SbAccountDAO;
import com.training.dataaccess.SbAccountDAOImpl;
import com.training.model.LoanAccount;
import com.training.model.SbAccount;

public class SbAccountService {
	
	  SbAccountDAO accountDao ;
		
		
	 public SbAccountService() {
		 
		 accountDao = new  SbAccountDAOImpl();
		 
	 }
	 
	 public List<SbAccount > getAllSbAccountdetails() {
		 
		 
		 List sbAccountList = accountDao.getAllSbAccountdetails();
			
			
			Iterator<SbAccount> iterator = sbAccountList.iterator();
			
			while(iterator.hasNext()){
				
				SbAccount pe = iterator.next();
				
				System.out.println("Customer Account Number   " +pe.getAccountNo());
				System.out.println("Customer Account holder name  "+pe.getAccountHolderName());
				System.out.println("Customer Account balance  "+pe.getBalanceAmount());
				System.out.println("Customer Account  Rate  "+pe. getRate());
				System.out.println("Customer Account Time  "+pe.getTime());
				
				
				}			
				
				
			return sbAccountList ;
			
			
			
		}
	 
	 
	 public SbAccount  getSbAccountByAccountNumber(int accountNo) {
		 
		 
		 SbAccount pe = accountDao.getSbAccountByAccountNumber(accountNo);
			
			

			System.out.println("Customer Account Number   " +pe.getAccountNo());
			System.out.println("Customer Account holder name  "+pe.getAccountHolderName());
			System.out.println("Customer Account balance  "+pe.getBalanceAmount());
			System.out.println("Customer Account  Rate  "+pe. getRate());
			System.out.println("Customer Account Time  "+pe.getTime());
			
			return pe;
			
		 }
	 
	 public void deleteLoanAccount(int accountNo) {
		 
		 
		 accountDao.deleteSbAccount( accountNo);
		 
		 
		 
	 }
	 

}
