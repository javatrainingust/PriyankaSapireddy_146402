package com.training.service;

public class LoanaccountDataRetriv {
	
public static void main(String arg[]){
		
		LoanAccountService service = new LoanAccountService();
		
		      //retrieving all  accounts 
		
			    service.getAllLoanAccountdetails();
				
				System.out.println("----------------------------------");
				
				
				service.getLoanAccountByAccountNumber(1234);
				
				System.out.println("----------------------------------");
				System.out.println("after deleting one account");
				System.out.println("----------------------------------");
				
				service.deleteLoanAccount(1235);
				service.getAllLoanAccountdetails();
				
		
				
	
	}

}
