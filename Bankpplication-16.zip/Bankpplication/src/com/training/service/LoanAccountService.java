package com.training.service;

import java.util.Iterator;
import java.util.List;

import com.training.dataaccess.FdAccountDAOImpl;
import com.training.dataaccess.FdaaccountDao;
import com.training.dataaccess.LoanAccountDAO;
import com.training.dataaccess.LoanAccountDAOImpl;
import com.training.model.FdAccount;
import com.training.model.LoanAccount;

public class LoanAccountService {
	
	 LoanAccountDAO accountDao ;
		
		
	 public LoanAccountService() {
		 
		 accountDao = new  LoanAccountDAOImpl();
		 
	 }
	 
	 public List<LoanAccount> getAllLoanAccountdetails() {
		 
		 
		 List loanAccountList = accountDao.getAllLoanAccountdetails();
			
			
			Iterator<LoanAccount> iterator = loanAccountList.iterator();
			
			while(iterator.hasNext()){
				
				LoanAccount pe = iterator.next();
				
				System.out.println("Customer Account Number   " +pe.getAccountNo());
				System.out.println("Customer Account holder name  "+pe.getAccountHolderName());
				System.out.println("Customer Account balance  "+pe.getBalanceAmount());
				System.out.println("Customer Account  loan outStanding Amount  "+pe. getLoanOutstanding());
				System.out.println("Customer Account ternure  "+pe.getTernure());
				
				
				}			
				
				
			return loanAccountList ;
			
			
			
		}
	 
	 
	 public LoanAccount getLoanAccountByAccountNumber(int accountNo) {
		 
		 
		 LoanAccount pe = accountDao.getLoanAccountByAccountNumber(accountNo);
			
			

			System.out.println("Customer Account Number   " +pe.getAccountNo());
			System.out.println("Customer Account holder name  "+pe.getAccountHolderName());
			System.out.println("Customer Account balance  "+pe.getBalanceAmount());
			System.out.println("Customer Account  loan outStanding Amount  "+pe. getLoanOutstanding());
			System.out.println("Customer Account ternure  "+pe.getTernure());
			
			
			return pe;
			
		 }
	 
	 public void deleteLoanAccount(int accountNo) {
		 
		 
		 accountDao.deleteLoanAccount( accountNo);
		 
		 
		 
	 }
	 
	 

}
