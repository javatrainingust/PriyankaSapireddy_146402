/***
 * ClassName: CurrentAccountDaOImpl 
 * 
 * Description:Implementing the CurrentAccountDao
 * 
 * Date :06-10-2020
 * 
 */

package com.training.dataaccess;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.training.model.CurrentAccount;
import com.training.model.FdAccount;

public class CurrentAccountDAOImpl implements CurrentAccountDAO {

	List currentAccountList;

	/* Adding to list invoking objects in constructors */

	public CurrentAccountDAOImpl() {

		currentAccountList = new ArrayList<FdAccount>();

		CurrentAccount fdac1 = new CurrentAccount(1234, "Priyanka", 10000, 40000);
		CurrentAccount fdac2 = new CurrentAccount(1235, "Sujatha", 90000, 100000);
		CurrentAccount fdac3 = new CurrentAccount(1236, "Karthika", 130000, 100000);

		currentAccountList.add(fdac1);
		currentAccountList.add(fdac2);
		currentAccountList.add(fdac3);

	}

	// get all the CurrentAccountdetails
	@Override
	public List<CurrentAccount> getAllCurrentAccounttdetails() {
		// TODO Auto-generated method stub
		return currentAccountList;
	}

	// get CurrentAccountdetails based on AccountNumber

	@Override
	public CurrentAccount getCurrentAccountByAccountNumber(int accountNo) {

		CurrentAccount currentAccount = null;

		Iterator<CurrentAccount> iterator = currentAccountList.iterator();

		while (iterator.hasNext()) {

			CurrentAccount pe = iterator.next();

			if (pe.getAccountNo() == accountNo) {

				currentAccount = pe;
			}

		}

		return currentAccount;
	}

	// deleting the cuurrent account based on accountNumber
	@Override
	public void deleteCurrentAccount(int accountNo) {
		// TODO Auto-generated method stub

		CurrentAccount currentAccount = null;

		for (int i = 0; i < currentAccountList.size(); i++) {

			currentAccount = (CurrentAccount) currentAccountList.get(i);

			if (currentAccount.getAccountNo() == accountNo) {

				currentAccountList.remove(i);

			}

		}
	}
}
