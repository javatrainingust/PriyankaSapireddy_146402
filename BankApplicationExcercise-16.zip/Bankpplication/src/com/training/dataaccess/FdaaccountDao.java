/**
 * InterfaceName: FdaaccountDao
 * 
 * Description:Interface for adding,retrieving,deleting details in currentAccount
 * 
 * Date -06-10-2020
 */


package com.training.dataaccess;

import java.util.List;

import com.training.model.FdAccount;

public interface FdaaccountDao {
	
	public List<FdAccount> getAllFdaAccountdetails();
 
	public FdAccount  getFdAccountByAccountNumber(int accountNo);
	
	public void deleteFdAccount(int accountNo);
	
	
}
