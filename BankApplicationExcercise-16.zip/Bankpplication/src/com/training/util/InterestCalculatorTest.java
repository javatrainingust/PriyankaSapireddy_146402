package com.training.util;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class InterestCalculatorTest {

	@Test
	void testCalculateInterestFloat() {
		int expected  = 1250;
		
		InterestCalculator ic = new InterestCalculator();
		
		 float actual = ic.calculateInterest(.5f);
		 assertEquals(expected,actual);
		 
		
		
	}

	@Test
	void testCalculateInterestFloatFloat() {
		
		int expected  = 350;
		
		InterestCalculator ic = new InterestCalculator();
		
		 float actual = ic.calculateInterest(50000f,0.7f);
		 assertEquals(expected,actual);
		
		
	}

}
