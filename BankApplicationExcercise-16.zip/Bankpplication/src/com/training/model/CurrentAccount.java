package com.training.model;

public class CurrentAccount extends Account {
	
	private float overDraftLimit ;
	
   private boolean overdraftLimitExceed ;
   
   public CurrentAccount() {
		
		// System.out.println("Inside CurrentAccount non-paramenterised constructor");
	}
	
	public CurrentAccount(int accountNo,String accountHolderName,float balanceAmount, float overDraftLimit) {
       
		super(accountNo, accountHolderName, balanceAmount);
		
		this.overDraftLimit = overDraftLimit;
	}
	@Override
	public String toString() {
		return "CurrentAccount [overdraftLimit=" + overDraftLimit +  "]";
	}
   

	public boolean isOverdraftLimitExceed() {
		return overdraftLimitExceed;
	}

	public void setOverdraftLimitExceed(boolean overdraftLimitExceed) {
		overdraftLimitExceed = overdraftLimitExceed;
	}

	public float getOverDraftLimit() {
		return overDraftLimit;
	}

	public void setOverDraftLimit(float overDraftLimit) {
		this.overDraftLimit = overDraftLimit;
	}
	
	public boolean isLimitExceed(float expenditure) {
		if(expenditure == overDraftLimit) {
			this.overdraftLimitExceed = true;
			
		}
		else {
			 this.overdraftLimitExceed =  false ;
		}
		
		System.out.println(" overdraft limit exceeded ?  " +this.isOverdraftLimitExceed());
		return overdraftLimitExceed;
	}

}
