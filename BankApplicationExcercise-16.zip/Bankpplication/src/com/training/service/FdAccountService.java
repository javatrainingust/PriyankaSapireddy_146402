/**
 * ClassName:FixedDepositeService
 * 
 * Description:Service class for processing get all acountDetails,Deleting account
 * 
 * Date-06-10-2020
 * */



package com.training.service;

import java.util.Iterator;
import java.util.List;

import com.training.dataaccess.FdAccountDAOImpl;
import com.training.dataaccess.FdaaccountDao;
import com.training.model.FdAccount;

public class FdAccountService {
	
	 FdaaccountDao  fdaaccountDao1 ;
	
	
	 public FdAccountService() {
		 
		 fdaaccountDao1 = new  FdAccountDAOImpl();
		 
	 }
	 /*Calling the getting method in implementation class*/
	 public List<FdAccount> getAllFdaAccountdetails() {
		 
		 
		 List fdAccountList = fdaaccountDao1.getAllFdaAccountdetails();
			
			
			Iterator<FdAccount> iterator = fdAccountList.iterator();
			
			while(iterator.hasNext()){
				
				FdAccount pe = iterator.next();
				
				System.out.println("Customer Account Number   " +pe.getAccountNo());
				System.out.println("Customer Account holder name  "+pe.getAccountHolderName());
				System.out.println("Customer Account balance  "+pe.getBalanceAmount());
				System.out.println("Customer Account ternure  "+pe.getTenure());
				System.out.println("Customer Account Rate  "+pe.getRate());
				
				}			
				
				
			return fdAccountList;
			
			
			
		}
	 
	 /*Calling the method in impl class by passing accountnum*/
	 public FdAccount getFdAccountByAccountNumber(int accountNo) {
		 
		 
		 FdAccount pe = fdaaccountDao1.getFdAccountByAccountNumber(accountNo);
			
			

			System.out.println("Customer Account Number   " +pe.getAccountNo());
			System.out.println("Customer Account holder name  "+pe.getAccountHolderName());
			System.out.println("Customer Account balance  "+pe.getBalanceAmount());
			System.out.println("Customer Account ternure  "+pe.getTenure());
			System.out.println("Customer Account Rate  "+pe.getRate());
			
			return pe;
			
		 }
	 
	 /*Calling Delete method   by passing accountnum*/
	 public void deleteFdAccount(int accountNo) {
		 
		 
		 fdaaccountDao1.deleteFdAccount( accountNo);
		 
		 
		 
	 }
	 
	 
	 
		
	 }


