/***
 * ClassName:CurrentAccountService
 * 
 * Description:Service class for the implementation of CurrentAccountDaoImplementation
 * 
 * Date-06-10-2020
 */



package com.training.service;

import java.util.Iterator;
import java.util.List;

import com.training.dataaccess.CurrentAccountDAO;
import com.training.dataaccess.CurrentAccountDAOImpl;
import com.training.dataaccess.FdAccountDAOImpl;
import com.training.dataaccess.FdaaccountDao;
import com.training.model.CurrentAccount;
import com.training.model.FdAccount;

public class CurrentAccountService {
	
        CurrentAccountDAO  accountDao1 ;
		
		
	 public CurrentAccountService() {
		 
		 accountDao1 = new  CurrentAccountDAOImpl();
		 
	 }
	 /*Calling the getting getAllCurrentAccounttdetails method in implementation class*/
	 public List<CurrentAccount> getAllCurrentAccounttdetails() {
		 
		 
		 List currentAccountList = accountDao1.getAllCurrentAccounttdetails();
			
			
			Iterator<CurrentAccount> iterator = currentAccountList.iterator();
			
			while(iterator.hasNext()){
				
				CurrentAccount pe = iterator.next();
				
				System.out.println("Customer Account Number   " +pe.getAccountNo());
				System.out.println("Customer Account holder name  "+pe.getAccountHolderName());
				System.out.println("Customer Account balance  "+pe.getBalanceAmount());
				System.out.println("Customer Account Rate  "+pe.getOverDraftLimit());
				
				}			
				
				
			return currentAccountList;
			
			
			
		}
	 
	 /*Calling the getCurrentAccountByAccountNumber method in impl class by passing accountnum*/
	 
	 public CurrentAccount  getCurrentAccountByAccountNumber(int accountNo) {
		 
		 
		 CurrentAccount pe = accountDao1.getCurrentAccountByAccountNumber( accountNo) ;
			
			

			System.out.println("Customer Account Number   " +pe.getAccountNo());
			System.out.println("Customer Account holder name  "+pe.getAccountHolderName());
			System.out.println("Customer Account balance  "+pe.getBalanceAmount());
			
			System.out.println("Customer Account Rate  "+pe.getOverDraftLimit());
			
			return pe;
			
		 }
	 
	 /*Calling Delete method   by passing accountnum*/
	 public void deleteFdAccount(int accountNo) {
		 
		 
		 accountDao1.deleteCurrentAccount( accountNo);
		 
		 
		 
	 }
	 
	 

}
