/**
 * InterfaceName: CurrentAccountDao
 * 
 * Description:Interface for adding,retrieving,deleting details in currentAccount
 * 
 * Date -06-10-2020
 */



package com.training.dataaccess;

import java.util.List;

import com.training.model.CurrentAccount;
import com.training.model.FdAccount;
/**
 * CurrentAccountDAO inteface with all abstract methods
 * @author sanga
 *
 */

public interface CurrentAccountDAO {
	
	

	public List<CurrentAccount> getAllCurrentAccounttdetails();
 
	public CurrentAccount  getCurrentAccountByAccountNumber(int accountNo);
	
	public void deleteCurrentAccount(int accountNo);
	
	 public boolean addCurrentAccount(CurrentAccount currentAccount);
	 
	 public void updateCurrentAccount(CurrentAccount currentAccount);
	    
	

}
