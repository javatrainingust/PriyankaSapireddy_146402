/***
 * ClassName: CurrentAccountDaOImpl 
 * 
 * Description:Implementing the CurrentAccountDao
 * 
 * Date :06-10-2020
 * 
 */

package com.training.dataaccess;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Repository;

import com.training.model.CurrentAccount;
import com.training.model.FdAccount;
import com.training.model.LoanAccount;
/**
 * Class with  implementation methods
 * @author sanga
 *
 */
@Repository
public class CurrentAccountDAOImpl implements CurrentAccountDAO {

	List currentAccountList;
	
	Set currentAccountSet;

	/* Adding to list invoking objects in constructors */

	public CurrentAccountDAOImpl() {

		currentAccountList = new ArrayList<CurrentAccount>();
		currentAccountSet = new  HashSet<CurrentAccount>();

		CurrentAccount fdac1 = new CurrentAccount(1234, "Priyanka", 10000, 40000);
		CurrentAccount fdac2 = new CurrentAccount(1235, "Sujatha", 90000, 100000);
		CurrentAccount fdac3 = new CurrentAccount(1236, "Karthika", 130000, 100000);

		currentAccountList.add(fdac1);
		currentAccountList.add(fdac2);
		currentAccountList.add(fdac3);

	}

	// get all the CurrentAccountdetails
	public List<CurrentAccount> getAllCurrentAccounttdetails() {
		// TODO Auto-generated method stub
		return currentAccountList;
	}

	// get CurrentAccountdetails based on AccountNumber

	public CurrentAccount getCurrentAccountByAccountNumber(int accountNo) {

		CurrentAccount currentAccount = null;

		Iterator<CurrentAccount> iterator = currentAccountList.iterator();

		while (iterator.hasNext()) {

			CurrentAccount pe = iterator.next();

			if (pe.getAccountNo() == accountNo) {

				currentAccount = pe;
			}

		}

		return currentAccount;
	}

	// deleting the cuurrent account based on accountNumber
	public void deleteCurrentAccount(int accountNo) {
		// TODO Auto-generated method stub

		CurrentAccount currentAccount = null;

		for (int i = 0; i < currentAccountList.size(); i++) {

			currentAccount = (CurrentAccount) currentAccountList.get(i);

			if (currentAccount.getAccountNo() == accountNo) {

				currentAccountList.remove(i);

			}

		}
	}

	public boolean addCurrentAccount(CurrentAccount currentAccount) {
		
	     boolean isAdded =  currentAccountSet.add(currentAccount);
			
			if(isAdded){
				currentAccountList.add(currentAccount);
				 
			}
			return isAdded;
	}

	public void updateCurrentAccount(CurrentAccount currentAccount) {
     
		Iterator iterator = currentAccountList.iterator();
		
		
		while(iterator.hasNext()){
			
			CurrentAccount pe =(CurrentAccount)iterator.next();
			
			if(pe.getAccountNo()==currentAccount.getAccountNo()){
				
				pe.setAccountHolderName(currentAccount.getAccountHolderName());
				pe.setOverDraftLimit(currentAccount.getOverDraftLimit());
				pe.setBalanceAmount(currentAccount.getBalanceAmount());
				
				
				
				
			}
		}
		
	}
}
