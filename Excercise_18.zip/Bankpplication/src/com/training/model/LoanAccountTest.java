package com.training.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class LoanAccountTest {

	@Test
	void testCalculate_emi() {
		
		int expected = 10000;
		
		LoanAccount la = new LoanAccount();
		
		float actual = la.calculate_emi();
		
		assertEquals(expected,actual);
		
		
	}

}
