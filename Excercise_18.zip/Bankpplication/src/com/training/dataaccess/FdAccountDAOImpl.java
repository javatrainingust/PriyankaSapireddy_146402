/**
 * ClassName:FixedDepositeDAOImpl
 * 
 * Description:Implements FixedDepositeDao And doing adding,deleting and searching
 * 
 * Date-06-10-2020
 */

package com.training.dataaccess;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.training.model.FdAccount;

public class FdAccountDAOImpl implements FdaaccountDao {

	/* List initialization invoking objects in constructors */

	List fdAccountList;
	
	private Set fdAccountSet;

	public FdAccountDAOImpl() {

		fdAccountList = new ArrayList<FdAccount>();
		fdAccountSet = new HashSet<FdAccount>();

		/*
		 * FdAccount fdac1 = new FdAccount(1234, "Priyanka", 10000, 4, 0.2f);
		 *  FdAccount fdac2 = new FdAccount(1235, "Sujatha", 90000, 4, 0.3f); 
		 *  FdAccount fdac3 = new FdAccount(1236, "Karthika", 130000, 4, 0.5f);
		 * 
		 * fdAccountList.add(fdac1); 
		 * fdAccountList.add(fdac2);
		 *  fdAccountList.add(fdac3)
		 */;

	}

	// get allFdaccount details

	@Override
	public List<FdAccount> getAllFdaAccountdetails() {

		return fdAccountList;
	}

	// get fdaccount details by accountNumber
	@Override
	public FdAccount getFdAccountByAccountNumber(int accountNo) {

		FdAccount fdAccount = null;

		Iterator<FdAccount> iterator = fdAccountList.iterator();

		while (iterator.hasNext()) {

			FdAccount pe = iterator.next();

			if (pe.getAccountNo() == accountNo) {

				fdAccount = pe;
			}

		}

		return fdAccount;
	}

	// delete fdaccount by accountNumber
	@Override
	public void deleteFdAccount(int accountNo) {

		FdAccount fdAccount = null;

		for (int i = 0; i < fdAccountList.size(); i++) {

			fdAccount = (FdAccount) fdAccountList.get(i);

			if (fdAccount.getAccountNo() == accountNo) {

				fdAccountList.remove(i);

			}

		}

	}

	@Override
	public boolean addFdAccount(FdAccount fdAccount) {
		
      boolean isAdded =  fdAccountSet.add(fdAccount);
		
		if(isAdded){
			fdAccountList.add(fdAccount);
			 
		}
		return isAdded;
		
		
	}

	@Override
	public void updateFdAccount(FdAccount fdAccount) {
           
		Iterator iterator = fdAccountList.iterator();
		
		
		while(iterator.hasNext()){
			
			FdAccount pe =(FdAccount)iterator.next();
			
			if(pe.getAccountNo()==fdAccount.getAccountNo()){
				
				pe.setAccountHolderName(fdAccount.getAccountHolderName());
				pe.setRate(fdAccount.getRate());
				pe.setTenure(fdAccount.getTenure());
				pe.setBalanceAmount(fdAccount.getBalanceAmount());
				
				
				
			}
			
			
		}
		
	}

}
