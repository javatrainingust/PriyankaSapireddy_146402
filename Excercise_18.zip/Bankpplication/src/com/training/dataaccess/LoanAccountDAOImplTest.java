/**
 * ClassName:LoanAccountDAOImplTest
 * 
 * Description:JuintTesting
 * 
 * Date-06-10-2020
 * */



package com.training.dataaccess;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.training.model.CurrentAccount;
import com.training.model.LoanAccount;
/**
 * Test class for testing the implemntation classes
 * @author sanga
 *
 */
class LoanAccountDAOImplTest {
	
	LoanAccountDAO dao =new  LoanAccountDAOImpl();
	LoanAccount la = new LoanAccount();

	@Test
	void testGetAllLoanAccountdetails() {
		int expected=3;
		List<LoanAccount> actual=dao.getAllLoanAccountdetails();
		assertEquals(expected,actual.size());
	}

	@Test
	void testGetLoanAccountByAccountNumber() {
		
		 String expectedValue="Priyanka";
			
			la=dao.getLoanAccountByAccountNumber(1234);
			
			String actualValue=la.getAccountHolderName();
			
			assertEquals(expectedValue,actualValue);
			
	
	}

	@Test
	void testDeleteLoanAccount() {

		int expectedSize=2;
		dao.deleteLoanAccount(1235);
		List<LoanAccount> actual=dao.getAllLoanAccountdetails();
		assertEquals(expectedSize, actual.size());
	
		
	}

}
