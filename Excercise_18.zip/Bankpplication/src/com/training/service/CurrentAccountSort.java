/**
 * ClassNAme: CurrentAccountTest
 * 
 * Description: class which contains main methods for getting outputs
 * 
 * Date-08-10-2020
 */


package com.training.service;
/**
 * class which contains main methods for getting outputs*/
public class CurrentAccountSort {
	
	
	/** 
	 * 
	 * main method
	 * */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		CurrentAccountService service =  new CurrentAccountService();
		System.out.println("printing all  accounts");
		
		service.getAllCurrentAccounttdetails();
		System.out.println("----------------------");
		System.out.println();
		System.out.println("Print accounts after sorting");
		service.getAllCurrentAccountSortedByNames();
		System.out.println("----------------------");
		System.out.println();
		System.out.println("Print accounts after sorting based on  OverDraftlimit");
		service.getAllCurrentAccountSortedByOverDraftLimit();
		

	}

}
