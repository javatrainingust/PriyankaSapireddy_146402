/***
 * ClassName:SbAccountService
 * 
 * Description:Service class for the implementation of SbAccountDaoImplementation
 * 
 * Date-06-10-2020
 */


package com.training.service;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.training.dataaccess.LoanAccountDAO;
import com.training.dataaccess.LoanAccountDAOImpl;
import com.training.dataaccess.SbAccountDAO;
import com.training.dataaccess.SbAccountDAOImpl;
import com.training.model.CurrentAccount;
import com.training.model.LoanAccount;
import com.training.model.SbAccount;

public class SbAccountService {
	
	  SbAccountDAO accountDao ;
	  
	  /**object creation using constructors*/
		
	  public SbAccountService() {
		 
		 accountDao = new  SbAccountDAOImpl();
		 
	 }
	  /**Calling the getting getAllSbAccountdetails method in implementation class*/
	  
	 public List<SbAccount > getAllSbAccountdetails() {
		 
		 
		 List sbAccountList = accountDao.getAllSbAccountdetails();
			
			
			Iterator<SbAccount> iterator = sbAccountList.iterator();
			
			while(iterator.hasNext()){
				
				SbAccount pe = iterator.next();
				
				System.out.println("Customer Account Number   " +pe.getAccountNo());
				System.out.println("Customer Account holder name  "+pe.getAccountHolderName());
				System.out.println("Customer Account balance  "+pe.getBalanceAmount());
				System.out.println("Customer Account  Rate  "+pe. getRate());
				System.out.println("Customer Account Time  "+pe.getTime());
				
				
				}			
				
				
			return sbAccountList ;
			
			
			
		}
	 
	 /**Calling the method in impl class by passing accountnum*/
	 
	 public SbAccount  getSbAccountByAccountNumber(int accountNo) {
		 
		 
		 SbAccount pe = accountDao.getSbAccountByAccountNumber(accountNo);
			
			

			System.out.println("Customer Account Number   " +pe.getAccountNo());
			System.out.println("Customer Account holder name  "+pe.getAccountHolderName());
			System.out.println("Customer Account balance  "+pe.getBalanceAmount());
			System.out.println("Customer Account  Rate  "+pe. getRate());
			System.out.println("Customer Account Time  "+pe.getTime());
			
			return pe;
			
		 }
	 
	 /**Calling Delete method   by passing accountnum*/
	 public void deleteLoanAccount(int accountNo) {
		 
		 
		 accountDao.deleteSbAccount( accountNo);
		 
	 }
	 
	 
public List<SbAccount> 	getAllSbAccountSortedByNames(){
		 
		 List<SbAccount> sbAccountList = accountDao.getAllSbAccountdetails();
			
			Collections.sort(sbAccountList);
			
			
			Iterator<SbAccount> iterator = sbAccountList.iterator();
			
			while(iterator.hasNext()){
				
				SbAccount pe = iterator.next();
				
				System.out.println("Customer Account Number   " +pe.getAccountNo());
				System.out.println("Customer Account holder name  "+pe.getAccountHolderName());
				System.out.println("Customer Account balance  "+pe.getBalanceAmount());
				System.out.println("Customer Account  Rate  "+pe. getRate());
				System.out.println("Customer Account Time  "+pe.getTime());
			}
			
			return  sbAccountList;
		 
	
		 }
	 
	 public List<SbAccount> getAllSbAccountSortedByBalance(){
			
			
		 List<SbAccount> sbAccountList = accountDao.getAllSbAccountdetails();
			
			Collections.sort(sbAccountList,new SbBalanceComparator());
			
			
			Iterator<SbAccount> iterator = sbAccountList.iterator();
			
			while(iterator.hasNext()){
				
				SbAccount pe = iterator.next();
				
				System.out.println("Customer Account Number   " +pe.getAccountNo());
				System.out.println("Customer Account holder name  "+pe.getAccountHolderName());
				System.out.println("Customer Account balance  "+pe.getBalanceAmount());
				System.out.println("Customer Account  Rate  "+pe. getRate());
				System.out.println("Customer Account Time  "+pe.getTime());
				}			
			
			
			
			return sbAccountList;
		}
	 
	 public void addSbAccount(SbAccount sbAccount) {
		 
		 boolean isAdded = accountDao.addSbAccount(sbAccount);
			
			if(!isAdded){
				
				System.out.println("The Account already exist");
			}
			else{
				System.out.println("The Account successfully added");
		 
		 
	 }
	 }
	 
			public void updateSbAccount(SbAccount sbAccount) {
				
				accountDao.updateSbAccount(sbAccount);
				
				
			}
				
				
			
		 
	 }
	 
	 
		 
	 
	 


