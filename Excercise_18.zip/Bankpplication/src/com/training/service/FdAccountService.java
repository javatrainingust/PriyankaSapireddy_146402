/**
 * ClassName:FixedDepositeService
 * 
 * Description:Service class for processing get all acountDetails,Deleting account
 * 
 * Date-06-10-2020
 * */



package com.training.service;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.training.dataaccess.FdAccountDAOImpl;
import com.training.dataaccess.FdaaccountDao;
import com.training.model.CurrentAccount;
import com.training.model.FdAccount;
/**
 * 
 * Service class for processing get all acountDetails,Deleting account
 */
public class FdAccountService {
	
	 FdaaccountDao  fdaaccountDao1 ;
	
	
	 public FdAccountService() {
		 
		 fdaaccountDao1 = new  FdAccountDAOImpl();
		 
	 }
	 /**
	  * 
	  * Calling the getting method in implementation class
	  * */
	 public List<FdAccount> getAllFdaAccountdetails() {
		 
		 
		 List fdAccountList = fdaaccountDao1.getAllFdaAccountdetails();
			
			
			Iterator<FdAccount> iterator = fdAccountList.iterator();
			
			while(iterator.hasNext()){
				
				FdAccount pe = iterator.next();
				
				System.out.println("Customer Account Number   " +pe.getAccountNo());
				System.out.println("Customer Account holder name  "+pe.getAccountHolderName());
				System.out.println("Customer Account balance  "+pe.getBalanceAmount());
				System.out.println("Customer Account ternure  "+pe.getTenure());
				System.out.println("Customer Account Rate  "+pe.getRate());
				
				}			
				
				
			return fdAccountList;
			
			
			
		}
	 
	 /**
	  * Calling the method in impl class by passing accountnum*/
	 public FdAccount getFdAccountByAccountNumber(int accountNo) {
		 
		 
		 FdAccount pe = fdaaccountDao1.getFdAccountByAccountNumber(accountNo);
			
			

			System.out.println("Customer Account Number   " +pe.getAccountNo());
			System.out.println("Customer Account holder name  "+pe.getAccountHolderName());
			System.out.println("Customer Account balance  "+pe.getBalanceAmount());
			System.out.println("Customer Account ternure  "+pe.getTenure());
			System.out.println("Customer Account Rate  "+pe.getRate());
			
			return pe;
			
		 }
	 
	 /**
	  * Calling Delete method   by passing accountnum*/
	 public void deleteFdAccount(int accountNo) {
		 
		 
		 fdaaccountDao1.deleteFdAccount( accountNo);
		 
		 
		 
	 }
	 /**
	  * get all accounts sorted by names
	  * @return
	  */
    public List<FdAccount> 	getAllFdAccountsSortedByNames(){
		 
		 List<FdAccount> fdAccountList = fdaaccountDao1.getAllFdaAccountdetails();
			
			Collections.sort(fdAccountList);
			
			
			Iterator<FdAccount> iterator = fdAccountList.iterator();
			
			while(iterator.hasNext()){
				
				FdAccount pe = iterator.next();
				
				System.out.println("Customer Account Number   " +pe.getAccountNo());
				System.out.println("Customer Account holder name  "+pe.getAccountHolderName());
				System.out.println("Customer Account balance  "+pe.getBalanceAmount());
				System.out.println("Customer Account ternure  "+pe.getTenure());
				System.out.println("Customer Account Rate  "+pe.getRate());
				
			}
			
			return  fdAccountList;
		 
	
		 }
	 
    /**
	  * get all accounts sorted by balance
	  * @return
	  */
	 public List<FdAccount> getAllFdAccountsSortedByBalance(){
			
			
		 List<FdAccount> fdAccountList = fdaaccountDao1.getAllFdaAccountdetails();
			
			Collections.sort(fdAccountList,new FdBalanceComparator());
			
			
			Iterator<FdAccount> iterator = fdAccountList.iterator();
			
			while(iterator.hasNext()){
				
				FdAccount pe = iterator.next();
				
				System.out.println("Customer Account Number   " +pe.getAccountNo());
				System.out.println("Customer Account holder name  "+pe.getAccountHolderName());
				System.out.println("Customer Account balance  "+pe.getBalanceAmount());
				System.out.println("Customer Account ternure  "+pe.getTenure());
				System.out.println("Customer Account Rate  "+pe.getRate());
				
				}			
			
			
			
			return fdAccountList;
		}
	 
	 /**
	  * get all accounts  by adding the accounts
	  * @return
	  */
	 
	 public void addFdAccount(FdAccount fdAccount) {
		 
		 boolean isAdded = fdaaccountDao1.addFdAccount(fdAccount);
			
			if(!isAdded){
				
				System.out.println("The Account already exist");
			}
			else{
				System.out.println("The Account successfully added");
		 
		 
	 }
	 
	 
		}
	 
	 /**
	  * get all accounts  by updating  the accounts
	  * @return
	  */
		public void updateFdAccount(FdAccount fdAccount) {
			
			fdaaccountDao1.updateFdAccount(fdAccount);
		}
}


