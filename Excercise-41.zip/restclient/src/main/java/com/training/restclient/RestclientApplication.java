/**
 * ClassName: RestclientApplication 
 * 
 * Description:  RestclientApplication class used for restfull resources 
 * Date: 28/10/2020
 */
package com.training.restclient;

import java.util.HashMap;
import java.util.Map;
import com.training.restclient.model.LoanAccount;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
/**
 *  RestclientApplication class used for restfull resources GET,PUT,DELETE,POST
 * @author sanga
 *
 */
@SpringBootApplication
public class RestclientApplication {
/**
 * Main Method 
 * @param args
 */
	public static void main(String[] args) {
		SpringApplication.run(RestclientApplication.class, args);
		
		       // getResource();
		
				//postResource();
				
				//putResource();
				
				//deleteResource();
				
				//getAllResources();
		
	}
	/**
	 * getResource  used to get a perticular account  y using account number  as key
	 */
public static void  getResource() {
		
		
		RestTemplate restTemplate = new RestTemplate();
		
		final String uri = "http://localhost:8001/banking/loanaccounts/{accountNo}";
	    	     
	    Map<String, Integer> params = new HashMap<String, Integer>();
	    params.put("accountNo", 1111);
	     
	    LoanAccount result = restTemplate.getForObject(uri, LoanAccount.class, params);
	    
	    System.out.println("Account holder name: "+result.getAccountHolderName());
	    System.out.println("Employee Designation: "+result.getBalanceAmount());
	    System.out.println("Employee Basic salary: "+result.getEmi());
	    System.out.println("Employee Basic salary: "+result.getLoanOutstanding());
	    System.out.println("Employee Basic salary: "+result.getTernure());
		
		
	}
	
	/**
	 * getAllResources method used to get all the accounts 
	 */
	public static void getAllResources() {
		
		System.out.println("Inside getAllResources() method");
	
		
		RestTemplate restTemplate = new RestTemplate();
		
		final String uri = "http://localhost:8001/banking/loanaccounts";
	    	     
	    	     
	    ResponseEntity<LoanAccount[]> response  = restTemplate.getForEntity(uri, LoanAccount[].class);
	    
	    LoanAccount[] employees = response.getBody();

	    
	    for(int i=0; i<employees.length;i++) {
	    	
	    	LoanAccount pe= (LoanAccount)employees[i];	    
	    	System.out.println("Account holder name: "+pe.getAccountHolderName());
		    System.out.println("Employee Designation: "+pe.getBalanceAmount());
		    System.out.println("Employee Basic salary: "+pe.getEmi());
		    System.out.println("Employee Basic salary: "+pe.getLoanOutstanding());
		    System.out.println("Employee Basic salary: "+pe.getTernure());
			
	    
	    }
		
		
		
	}
	/**
	 * postResource method to post a account 
	 */
	public static void postResource() {
		
		
		RestTemplate restTemplate = new RestTemplate();
		
		final String uri = "http://localhost:8001/banking/loanaccounts";
	
		LoanAccount pe = new LoanAccount(2222,"Sathiya",23303,0.4f,0.1f,3);
	
		LoanAccount result = restTemplate.postForObject( uri, pe, LoanAccount.class);
		
		
	}
	
	/**
	 * putResource method is to update the account 
	 */
	public static void putResource() {
		
		RestTemplate restTemplate = new RestTemplate();
		
		final String uri = "http://localhost:8001/banking/loanaccounts/{accountNo}";
	    	     
	    Map<String, Integer> params = new HashMap<String, Integer>();
	    params.put("accountNo", 5004);
	     
	    LoanAccount updatedEmployee = new LoanAccount(5004,"Sathiya",23303,0.4f,0.1f,3);
	    
	     restTemplate.put(uri, updatedEmployee, params);
		
		
		
		
	}
	/**
	 * deleteResource is used to delete tne account 
	 */
	public static void deleteResource() {
		
		RestTemplate restTemplate = new RestTemplate();
		
		final String uri = "http://localhost:8001/banking/loanaccounts/{accountNo}";
	    	     
	    Map<String, Integer> params = new HashMap<String, Integer>();
	    params.put("accountNo", 5004);
	     
	     restTemplate.delete(uri, params);
	}
}
