/**
  * Class name: Account
 * 
 * Description: this is a base class for Account sub type
 * 
 * Date:30/09/2020
 * 
 */


package com.training.restclient.model;


/**
 * this is a base class for Account sub type
 * @author sanga
 *
 */
public class Account {
	


	private int  accountNo;
	protected String accountHolderName;
	protected float balanceAmount;
	
	public int getAccountNo() {
		return accountNo;
	}
	
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	
	public String getAccountHolderName() {
		return accountHolderName;
	}
	
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	
	public float getBalanceAmount() {
		return balanceAmount;
	}
	
	
    public void setBalanceAmount(float balanceAmount) {
		this.balanceAmount = balanceAmount;
	}

	
	  @Override
		public String toString() {
			return "Account [accountNumber=" +  accountNo + ", accountHolderName=" + accountHolderName + "]";
		}
	    
	  /* constructor with non-parameters  */
	  public Account() {
		 super();
		 System.out.println("inside account non-parameterised constructor");
	  }
	  
	  /* constructor with  parameters */
	  public Account(int accountNo,String accountHolderName,float balanceAmount) {
		  super();
		  this.accountNo =accountNo;
		  this.accountHolderName=accountHolderName;
		  this.balanceAmount = balanceAmount;
	  }
	  
	  
	    
	   
	
}
