/**
 * Class : AboutMeController
 * 
 * Description: class contains getMyHobbies  which is annotated by @Controller
 * 
 * Date:14/10/2020
 * 
 */


package com.ust.training.model;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AboutMeController {
	
	@RequestMapping("/hobbies")
	public String getMyHobbies(){
		return "hobbies";
	}

}
