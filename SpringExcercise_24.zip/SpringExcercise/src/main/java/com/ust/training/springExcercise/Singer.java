/**
 * Class:  Singer 
 * 
 * Description: Class that implements Performer interface  and  implemnts performer method 
 * 
 * Date : 12/10/2020
 */



package com.ust.training.springExcercise;
/**
 *  Class that implements Performer interface  
 * 
 */
public class Singer implements Performer {

	 String singername;	

/**
 * Singer constructor
 *
 */
public  Singer (String singer) {
	   
	  // System.out.println(" inside the singer constructor");
	   
	   singername = singer;
	   
	   
   }
 /**
  * method performer that prints a message
  */
	public void perform() {
		
    
	System.out.println("song property is=  "+singername);
		
	}
	

}
