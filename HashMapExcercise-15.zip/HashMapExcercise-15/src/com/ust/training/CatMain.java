package com.ust.training;

import java.util.HashMap;
import java.util.Map;





public class CatMain {
	
	public static void main(String[] args) {
		
		
		
		Cat cat1 = new Cat("rosy",2);

		Cat cat2 = new Cat("pinky",3);

		Cat cat3 = new Cat("rosy",2);
		
    Map catOwners = new HashMap<Cat,String>();
		
		catOwners.put(cat1, "Kumar");
		
		catOwners.put(cat2, "Ravi");
		
		catOwners.put(cat3, "Vijay");
		
		System.out.println("owner of rosy is:  "+catOwners.get(new Cat("rosy",2)));
		System.out.println("owner of pinky is:  "+catOwners.get(new Cat("pinky",3)));
		System.out.println("owner of rosy is:  "+catOwners.get(new Cat("rosy",2)));
	
		
		
		
		
	}

	

}
