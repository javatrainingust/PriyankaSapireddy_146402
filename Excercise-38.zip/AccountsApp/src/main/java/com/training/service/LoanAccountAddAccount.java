/**
 * Name: LoanAccountAddAccount
 * 
 * Description: This is  for adding and updating the  CurrentAccount.
 * 
 * Date: 06/10/2020
 */


package com.training.service;

import com.training.model.CurrentAccount;
import com.training.model.LoanAccount;

/**
 * CurrentAccountAddAccount class is for display outputs
 * */
public class LoanAccountAddAccount {
	/**
	 * Main method
	 * 
	 */
	public static void main(String[] args) {
		
		 LoanAccountService service = new LoanAccountService();
			
			service.addLoanAccount(new LoanAccount(1234,"Priyanka",10000,1.2f,10000,3));
			service.addLoanAccount(new LoanAccount(1235,"Sujatha",90000,1.4f,10000,2));
			service.addLoanAccount(new LoanAccount(1235,"Sujatha",90000,1.4f,10000,2));
			
			System.out.println("Printing all Accounts");	
			service.getAllLoanAccountdetails();
			System.out.println("---------------------------------------------");	
			
	        service.updateLoanAccount(new LoanAccount(1235,"Sujatha",70000,1.4f,10000,2));
			
			System.out.println("Printing all updated Accounts");	
			
			service.getAllLoanAccountdetails();
	}

}
