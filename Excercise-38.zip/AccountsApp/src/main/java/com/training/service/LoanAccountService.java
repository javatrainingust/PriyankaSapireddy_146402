/***
 * ClassName:LoanAccountService
 * 
 * Description:Service class for the implementation of LoanAccountDaoImplementation
 * 
 * Date-06-10-2020
 */



package com.training.service;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.dataaccess.FdAccountDAOImpl;
import com.training.dataaccess.FdaaccountDao;
import com.training.dataaccess.LoanAccountDAO;
import com.training.dataaccess.LoanAccountDAOImpl;
import com.training.model.CurrentAccount;
import com.training.model.FdAccount;
import com.training.model.LoanAccount;
@Service
public class LoanAccountService {
	
	@Autowired
	private  LoanAccountDAO accountDao ;
		
	 /**
	  * object creation using constructors*/	
	 public LoanAccountService() {
		 
		 accountDao = new  LoanAccountDAOImpl();
		 
	 }
	 
	  /**
	   * Calling the getting  getAllLoanAccountdetail method in implementation class
	   * */
	 public List<LoanAccount> getAllLoanAccountdetails() {
		 
		 
		 List loanAccountList = accountDao.getAllLoanAccountdetails();
			
			
			Iterator<LoanAccount> iterator = loanAccountList.iterator();
			
			while(iterator.hasNext()){
				
				LoanAccount pe = iterator.next();
				
				System.out.println("Customer Account Number   " +pe.getAccountNo());
				System.out.println("Customer Account holder name  "+pe.getAccountHolderName());
				System.out.println("Customer Account balance  "+pe.getBalanceAmount());
				System.out.println("Customer Account  loan outStanding Amount  "+pe. getLoanOutstanding());
				System.out.println("Customer Account ternure  "+pe.getTernure());
				
				
				}			
				
				
			return loanAccountList ;
			
			
			
		}
	 

	 /**
	  * Calling the getLoanAccountByAccountNumbe method in impl class by passing accountnum
	  * */
	 public LoanAccount getLoanAccountByAccountNumber(int accountNo) {
		 
		 
		 LoanAccount pe = accountDao.getLoanAccountByAccountNumber(accountNo);
			
			

			System.out.println("Customer Account Number   " +pe.getAccountNo());
			System.out.println("Customer Account holder name  "+pe.getAccountHolderName());
			System.out.println("Customer Account balance  "+pe.getBalanceAmount());
			System.out.println("Customer Account  loan outStanding Amount  "+pe. getLoanOutstanding());
			System.out.println("Customer Account ternure  "+pe.getTernure());
			
			
			return pe;
			
		 }
	 /**
	  * Calling Delete method   by passing accountnum
	  * */
	 public void deleteLoanAccount(int accountNo) {
		 
		 
		 accountDao.deleteLoanAccount( accountNo);
		 
		 }
	 
	 /**
	  * Calling getAllLoanAccountSortedByNames method  
	  * */
   public List<LoanAccount> 	getAllLoanAccountSortedByNames(){
		 
		 List<LoanAccount>  loanAccountList = accountDao.getAllLoanAccountdetails();
			
		  //Collections.sort(loanAccountList);
			
		 Stream<LoanAccount>  loanAccountStream = loanAccountList.stream();
			
			Stream<LoanAccount> sortedStream = loanAccountStream.sorted();
			
			List sortedloanAccountListList = sortedStream.collect(Collectors.toList());
			
			
			Iterator<LoanAccount> iterator = sortedloanAccountListList.iterator();
			
			while(iterator.hasNext()){
				
				LoanAccount pe = iterator.next();
				
				System.out.println("Customer Account Number   " +pe.getAccountNo());
				System.out.println("Customer Account holder name  "+pe.getAccountHolderName());
				System.out.println("Customer Account balance  "+pe.getBalanceAmount());
				System.out.println("Customer Account  loan outStanding Amount  "+pe. getLoanOutstanding());
				System.out.println("Customer Account ternure  "+pe.getTernure());
			}
			
			return  loanAccountList;
		 
	
		 }
	 
   /**
	  * Calling getAllLoanAccountSortedByLoanOutStandingAmount method  
	  * */
	 public List<LoanAccount> getAllLoanAccountSortedByLoanOutStandingAmount(){
			
			
		 List<LoanAccount>  loanAccountList = accountDao.getAllLoanAccountdetails();
			
			//Collections.sort(loanAccountList,new LoanOutStandingAmountComparator());
		 
		 Stream<LoanAccount>  loanAccountStream = loanAccountList.stream();
			
			Stream<LoanAccount> sortedStream = loanAccountStream.sorted(new LoanOutStandingAmountComparator());
			
			List sortedloanAccountListList = sortedStream.collect(Collectors.toList());
			
			
			Iterator<LoanAccount> iterator = sortedloanAccountListList.iterator();
			
			while(iterator.hasNext()){
				
				LoanAccount pe = iterator.next();
				System.out.println("Customer Account Number   " +pe.getAccountNo());
				System.out.println("Customer Account holder name  "+pe.getAccountHolderName());
				System.out.println("Customer Account balance  "+pe.getBalanceAmount());
				System.out.println("Customer Account  loan outStanding Amount  "+pe. getLoanOutstanding());
				System.out.println("Customer Account ternure  "+pe.getTernure());
				
				}			
			
			
			
			return loanAccountList;
		}
	 
	 /**
	  * Calling addLoanAccount method  
	  * */
	 public void addLoanAccount(LoanAccount loanAccount) {
		 
		 boolean isAdded = accountDao.addLoanAccount(loanAccount);
			
			if(!isAdded){
				
				System.out.println("The Account already exist");
			}
			else{
				System.out.println("The Account successfully added");
		 
		 
	 }
		 
		 
	 }
	 
	 /**
	  * Calling updateLoanAccount method  
	  * */
	 public void updateLoanAccount(LoanAccount loanAccount) {
		 
		 accountDao.updateLoanAccount(loanAccount);
	 }
	 

}
