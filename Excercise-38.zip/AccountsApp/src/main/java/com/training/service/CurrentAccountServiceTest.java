/**
 * ClassNAme: CurrentAccountTest
 * 
 * Description: Test for CurrentAccountDaoImplementation
 * 
 * Date-08-10-2020
 */
package com.training.service;



import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;

import com.training.model.Account;
import com.training.model.CurrentAccount;

/**
 * Testing 2 methods in Implementation class
 * 
 * 1.AddCurrent Account
 * 
 * 2.UpdateCurrentAccount
 */
class CurrentAccountServiceTest {
	
	 CurrentAccountService service = new  CurrentAccountService();
	 CurrentAccount fd = new CurrentAccount();
	
//	 @Test
//	void testGetAllCurrentAccountSortedByNames() {
//		
//		String expectedValue = "Karthika";
//		
//		List<CurrentAccount> currentAccount = service.getAllCurrentAccountSortedByNames();
//		
//		String actualValue = currentAccount.get(0).getAccountHolderName();
//		
//		assertEquals(expectedValue, actualValue);
//	}
//
//	@Test
//	void testGetAllCurrentAccountSortedByOverDraftLimit() {
//		
//       String expectedValue = "Priyanka";
//		
//		List<CurrentAccount> currentAccount = service.getAllCurrentAccountSortedByOverDraftLimit();
//		
//		String actualValue = currentAccount.get(0).getAccountHolderName();
//		
//		assertEquals(expectedValue, actualValue);
//		
//	}
	 /*
	  * Testing method AddCurrentaccount
	  * 
	  */
	
     @Test
	
	void testAddCurrentAccount() {
		int expectedSize = 2;
		service.addCurrentAccount(new CurrentAccount(1234, "Priyanka", 10000, 40000));
		service.addCurrentAccount(new CurrentAccount(1235, "Sujatha", 90000, 100000));
		List<CurrentAccount> actual = service.getAllCurrentAccounttdetails();
		assertEquals(expectedSize, actual.size());
		
	}
     
     
     /*
	  * Testing method updateCurrentaccount
	  * 
	  */
     
	@Test
 	
 	void testUpdateCurrentAccount() {
 		
 		float expectedValue = 100000;
 		
 		service.updateCurrentAccount(new CurrentAccount(1235, "Sujatha", 100000, 100000));
 		 
 		fd = service. getCurrentAccountByAccountNumber(1235);
 		
 		float actualValue = fd.getBalanceAmount();
 		
 		assertEquals(expectedValue, actualValue);
 		
 		
 	}

	
  
	
	
	

}
