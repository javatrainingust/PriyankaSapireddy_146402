/**
 * ClassName:  CurrentaccountOverDraftLimitComparator
 * 
 * Description:  for  comparing process 
 * 
 * Date-06-10-2020
 * */


package com.training.service;

import java.util.Comparator;

import com.training.model.CurrentAccount;
/**
 * Class  CurrentaccountOverDraftLimitComparator  for comparing  the iutputs
 * 
 */
public class CurrentaccountOverDraftLimitComparator implements Comparator<CurrentAccount> {

	
	public int compare(CurrentAccount o1, CurrentAccount o2) {
		// TODO Auto-generated method stub
		return  (int) (o1.getOverDraftLimit()-o2.getOverDraftLimit());
	}

}
