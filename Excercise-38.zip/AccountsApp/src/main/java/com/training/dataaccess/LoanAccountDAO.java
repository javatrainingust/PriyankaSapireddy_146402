/**
 * InterfaceName: LoantAccountDao
 * 
 * Description:Interface for adding,retrieving,deleting details in currentAccount
 * 
 * Date -06-10-2020
 */



package com.training.dataaccess;

import java.util.List;

import com.training.model.FdAccount;
import com.training.model.LoanAccount;
/**
 * Interface for adding,retrieving,deleting details in currentAccount
 * @author sanga
 *
 */
public interface LoanAccountDAO {
	
	public List<LoanAccount> getAllLoanAccountdetails();
	 
	public LoanAccount  getLoanAccountByAccountNumber(int accountNo);
	
	public void deleteLoanAccount(int accountNo);
	
	 public boolean addLoanAccount(LoanAccount loanAccount);
	    
	  public void updateLoanAccount(LoanAccount loanAccount);

}
