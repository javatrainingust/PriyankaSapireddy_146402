/**
 * ClassName: OneManBand
 * 
 * Description:  class that implements Performer interface
 * 
 * Date:12-10-2020
 * 
 */



package com.ust.training.springExcercise;

import java.util.Iterator;
import java.util.List;

/**
 * class  OneManBand that implements Performer interface
 * @author sanga
 *
 */
public class OneManBand implements Performer {


	List<Instrument> instruments;

	
	
	public List<Instrument> getInstruments() {
		return instruments;
	}

	public void setInstruments(List<Instrument> instruments) {
		this.instruments = instruments;
	}

	
	/***
	 * Perform iteration through the Instrument list
	 */
	
	public void perform() {
		// TODO Auto-generated method stub
		

		Iterator itr = instruments.iterator();
		
		while(itr.hasNext())
		{
			
			Instrument instrumentsList =(Instrument) itr.next();
		
			instrumentsList.play();

		}
		
	
		
		
	
		}
		
	
}
