/***
 * ClassName:Flute
 * 
 * Description: Class Implementing instrument and overriding the method play  in instrument
 * 
 * Date:12-10-2020
 * 
 */



package com.ust.training.springExcercise;
  /***
	*
	* Class Implementing instrument and overriding the method play  in instrument
	*
	*/
	public class Flute implements Instrument {

		/***
		 * Play method displays Playing Flute
		 */
		
		public void play() {
			// TODO Auto-generated method stub
			System.out.println(" Flute is Playing ");
		}

	}



