/**
 * class : MainMethod
 * 
 * Description: MainMethod class which contains a main method to access all classes
 * 
 * Date: 12/10/2020
 */
package com.ust.training.springExcercise;

import org.springframework.context.support.ClassPathXmlApplicationContext;
/**
 * MainMethod class which contains a main method to access all classes
 * @author sanga
 *
 */
public class MainMethod {
/**
 * Main method 
 * @param args
 */
	public static void main(String[] args) {
		
		
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

		OneManBand oneManBand = context.getBean("OneManBand",OneManBand.class);
		
		oneManBand.perform();
	}

}
