/**
 * Class: Saxaphone
 * 
 * Description:  Saxaphone class that implements  Instrument Interface
 * 
 * Date: 12/10/2020
 * 
 */



package com.ust.training.springExcercise;

/**
 * Saxophone class that implements Instrument Interface
 * 
 * @author sanga
 *
 */
public class Saxaphone implements Instrument {
	/**
	 * Saxaphone default constructor
	 */
	public Saxaphone() {

		System.out.println("inside Saxophone constructor");
	}

	/**
	 * play method that prints some text
	 */
	public void play() {

		System.out.println(" Saxophone is  playing");

	}

}
