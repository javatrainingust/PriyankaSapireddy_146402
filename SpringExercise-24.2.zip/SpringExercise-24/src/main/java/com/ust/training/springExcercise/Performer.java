/**
 * ClassName:Performer
 * 
 * Description: Interface  with abstract method
 * 
 * Date:12-10-2020
 * 
 */


package com.ust.training.springExcercise;
/**
 * Interface  with abstract method Performer
 * @author sanga
 *
 */
public interface Performer {
	
	/*perform method declaration*/
	public void perform();

}
