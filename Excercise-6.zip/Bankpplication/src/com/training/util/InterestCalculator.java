package com.training.util;

public class InterestCalculator {
	
	private float principle = 50000f ;
	
	private float timePeriod= 5f ;
	
	
	
	public float calculateInterest(float rateOfInterest) {
		
		float si = (principle*timePeriod*rateOfInterest)/100 ;
		
		System.out.println("Simple Interest is=   "+si);
		return si;
		}
	

	public Float calculateInterest(float principle,float rate) {
		
		int time =1;
		float intrest = principle*time*rate; 
		
		return intrest;
		
	}
		

}
