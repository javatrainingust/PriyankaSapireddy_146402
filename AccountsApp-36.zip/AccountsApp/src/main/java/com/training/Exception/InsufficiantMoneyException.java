/**
 * ClassName: InsufficiantMoneyException
 * 
 * Description: class that extends exception To throw the InsufficiantMoneyException  for the base class method
 * 
 * date:9/10/2020
 */



package com.training.Exception;

/**
 *  class that extends exception To throw the InsufficiantMoneyException  for the base class method 
 * @author sanga
 *
 */

public class InsufficiantMoneyException extends Exception{
	
	float moneyToWithdraw;
 /**
  *  To throw the InsufficiantMoneyException  for the base class method moneyToWithdraw
  * @param moneyToWithdraw
  */
	public InsufficiantMoneyException(float moneyToWithdraw) {
		super();
		this.moneyToWithdraw = moneyToWithdraw;
	}

	@Override
	public String toString() {
		return "Insufficiant balance in your account to withdraw  this amount" + moneyToWithdraw;
	}

}
