/**
 * Class Name: FdAccountController
 * 
 * Description: Class which is used give the http request to server by using @Controller and @RequestMapping
 * 
 * Date:15/10/2020
 */
package com.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.service.FdAccountService;


import com.training.model.FdAccount;
import com.training.model.SbAccount;

/**
 * FdAccountController Class which is used give the http request to server by using @Controller and @RequestMapping
 * @author sanga
 *
 */
@Controller
public class FdAccountController {
	
	@Autowired
	private FdAccountService service;
	
	/**
	 * getAllAccounts method to get all FD Accounts
	 * @return to fdAccountList
	 */
	
	@RequestMapping("/fdaccounts")
	public String getAllfdAccounts(Model model){
		
		System.out.println("Inside controller getAllAccounts ");
		
		List<FdAccount> employeeList = service.getAllFdaAccountdetails();
		
		model.addAttribute("fdaccounts",employeeList );
		
		
		return "fdAccountList";
		

}
	/**
	 * showFdAccountForm method to show showFdAccountForm
	 * @return to fdAccountList
	 */
	@RequestMapping("/showFdAccountform")
	public String  showFdAccountForm(Model model){
		
		FdAccount pe = new FdAccount();
		
	   model.addAttribute("key",pe );
		
		
		return "addFdAccount";
		

}

	/**
	 * addEmployee  method to addFdAccount
	 * @param pe
	 * @return "redirect:/fdaccounts"
	 */
	@RequestMapping("/addFdAccount")
	public String addEmployee(@ModelAttribute("fdAccount") FdAccount pe) {
		
		
		service.addFdAccount(pe);
		
		return "redirect:/fdaccounts";
		
		
	}
	/**
	 * updatefdAccount  method to updatefdAccount
	 * @param pe
	 * @return "redirect:/fdaccounts"
	 */
	@RequestMapping("/updateFdAccount")
	public String updatefdAccount(@ModelAttribute("fdAccount") FdAccount pe) {
		
		
		service.updateFdAccount(pe);
		
		return "redirect:/fdaccounts";
		
		
	}
	
	/**
	 * getaccount method to getFdAccount By AccountNumber 
	 * @return to fdAccountList
	 */
	
	@RequestMapping("/viewFdAccount")
	public String getaccount(@RequestParam("accountNo")String accountNo,Model model) {
		
		
		FdAccount pe = service.getFdAccountByAccountNumber(Integer.parseInt(accountNo));
		
		model.addAttribute("key", pe);
		
		
		return "viewFdAccount";
		
		
	}
	
	@RequestMapping("/sortAccounyByName")
	public String updatefdAccountsbyName(Model model){
		
		System.out.println("Inside controller getAllAccounts ");
		
		List<FdAccount> employeeList = service.getAllFdAccountsSortedByNames();
		
		model.addAttribute("sortAccounyByName",employeeList );
		
		
		return "fdAccountList";
		

}
	@RequestMapping("/sortAccounyByBalance")
	public String updatefdAccountsbyBalance(Model model){
		
		System.out.println("Inside controller getAllAccounts ");
		
		List<FdAccount> employeeList = service.getAllFdAccountsSortedByBalance();
		
		model.addAttribute("sortAccounyByBalance",employeeList );
		
		
		return "fdAccountList";
		

}
	
	/**
	 * deleteFdaccount method to  delete Fdaccount By AccountNumber 
	 * @return to fdAccountList
	 */
	@RequestMapping("/deletefdAccount")
	public String deleteFdaccount(@RequestParam("accountNo")String accountNo,Model model) {
		
		
	 service.deleteFdAccount(Integer.parseInt(accountNo));
		
	
		
		
	 return  "redirect:/fdaccounts";
		
		
	}
}
