/**
 * ClassName: CountryController
 * 
 * Description: Class is  controller for Country class used to Develop REST web service  POST,GET,PUT,DELETE
 * 
 * Date: 22/10/2020
 *
 */
package com.ust.training.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.ust.training.model.Country;
/**
 * Class is  controller for Country class used to Develop REST web service  POST,GET,PUT,DELETE
 * @author sanga
 *
 */
@RestController
public class CountryController {
	
	Map<String,Country> countryDatabase = new HashMap<String,Country>();
	
	/**
	 * getDummyCountry method is just to craete a dummy country to access 
	 * @return
	 */
	@RequestMapping(value="/countries/dummy",method=RequestMethod.GET) 
	public Country getDummyCountry() {
		
		Country country = new Country();
		
		country.setCode("IN");
		country.setDescription("India");
		country.setMessage("Dummy country is created");
		
		
		countryDatabase.put("IN",country);
		
		return country;	
		
		
		
	}
	/**
	 * createCountry is used to create a country by using POST method
	 * @param country
	 * @return
	 */
	@RequestMapping(value="/countries",method=RequestMethod.POST) 
	public Country createCountry(@RequestBody Country country) {
		
		System.out.println("country code : "+ country.getCode());
		
		if(countryDatabase.containsKey(country.getCode())) {
			
			country.setMessage("country already exist");
			
		}
		else {
			
			countryDatabase.put(country.getCode(), country);
			country.setMessage("country created");
			
		}
				
		return country;
		
		
	}
	/**
	 * getAllCountries is ued to get all countries by using GET method 
	 * @return
	 */
	@RequestMapping(value="/countries",method=RequestMethod.GET) 
	public List<Country> getAllCountries() {
		
		List<Country> countries  = new ArrayList<Country>();
		
		Set<String> countrycodes = countryDatabase.keySet();
		
		for(String i: countrycodes) {
			
			countries.add(countryDatabase.get(i));
		}
			
		
		return countries;	
		
		
		
	}
	/**
	 * getCountry is ued to get a  country by using GET method 
	 * @return
	 */
	@RequestMapping(value="/countries/{code}",method=RequestMethod.GET) 
	public Country getCountry(@PathVariable String code) {
		
		Country  country = new Country();
		
		if(countryDatabase.containsKey(code)) {
			
			country = countryDatabase.get(code);
			country.setMessage("country retrieved");
			
		}
		else {
			country.setMessage("country not found");
			
		}
				
		return country;
	}
	
	/**
	 * updateContry is ued to update a  country by using PUT method 
	 * @return country
	 */
	@RequestMapping(value="/countries/{code}",method=RequestMethod.PUT)
	public Country updateContry(@PathVariable String code,@RequestBody Country ModifiedCountry ) {
		
		Country  country = new Country();
		
		if(countryDatabase.containsKey(code)) {
			
			country = countryDatabase.get(code);
			
			country.setDescription(ModifiedCountry.getDescription());
			
			country.setMessage("country updated");
			
		}
		else {
			country.setMessage("country not found");
			
		}
				
		return country;
	}
	/**
	 * deleteCountry is ued to delete a  country by using DELETE method 
	 * @param code
	 * @return
	 */
	@RequestMapping(value="/countries/{code}",method=RequestMethod.DELETE)
	public Country deleteCountry(@PathVariable String code) {
		
		Country  country = new Country();
		
		if(countryDatabase.containsKey(code)) {
			country = countryDatabase.get(code);
			
			countryDatabase.remove(code);
			
			country.setMessage("country deleted");
			
		}
		else {
			
			country.setMessage("country not deleted ");
		}
				
		return country;
		
		
		
	}
	

}
