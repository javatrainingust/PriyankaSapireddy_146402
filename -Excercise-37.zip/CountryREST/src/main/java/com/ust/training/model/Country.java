/**
 * ClassName: Country
 * Description: Class is used to Develop REST webservice  POST,GET,PUT,DELETE
 * 
 * Date: 22/10/2020
 *
 */
package com.ust.training.model;
/**
 * Class Country is used to  Develop REST webservice
 * @author sanga
 *
 */
public class Country {
	
	 private String code ;

	 private String Description;
	 
	 private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}
	
	

}
