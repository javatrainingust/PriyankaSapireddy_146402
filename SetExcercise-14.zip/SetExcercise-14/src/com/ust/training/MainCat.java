/**
 * ClassName:Cat
 * 
 * Description:MainCat class, 
 * 
 * Date:05-10-2020
 */


package com.ust.training;

import java.util.HashSet;
import java.util.Set;



public class MainCat {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		boolean[] b=new boolean[3];
		
		/* Creating instance for set*/
		
		
        Set s = new HashSet<Cat>();
		
		
	    Cat cat1 = new Cat("rosy",2);

		Cat cat2 = new Cat("pinky",3);

		Cat cat3 = new Cat("rosy",2);
		
		
		//Adding  cat  objects using boolean array
        b[0] = s.add(cat1);
		
		b[1] = s.add(cat2);
		
		b[2] = s.add(cat3);		
		
		 // iterating values using forEach loop
		for(int i=0;i<b.length;i++){
			System.out.println(" Cat  : "+b[i]);
		}
		
		
		
		

	}

}
