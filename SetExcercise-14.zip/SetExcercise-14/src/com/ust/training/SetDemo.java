/**
 * ClassName:Cat
 * 
 * Description:SetDemo Model Class, 
 * 
 * Date:05-10-2020
 */

 /*First case is implementation*/

package com.ust.training;

import java.util.HashSet;
import java.util.Set;

public class SetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

         /* Creating instance for set*/
		
		boolean[] b=new boolean[3];
		Set s=new HashSet();
		b[0]=s.add("test");
		b[1]=s.add("Work");
		b[2]=s.add("test");
		
	  // iterating values using forEach loop
		for(Object o:s){
			System.out.println("Value inside set : "+o);
		}
		
	}

}
