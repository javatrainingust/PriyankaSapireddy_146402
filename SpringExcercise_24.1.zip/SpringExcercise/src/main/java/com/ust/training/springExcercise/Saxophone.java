/**
 * Class: Saxophone
 * 
 * Description:  Saxophone class that implements  Instrument Interface
 * 
 * Date: 12/10/2020
 * 
 */

package com.ust.training.springExcercise;

/**
 * Saxophone class that implements Instrument Interface
 * 
 * @author sanga
 *
 */
public class Saxophone implements Instrument {
	/**
	 * Saxophone default constructor
	 */
	public Saxophone() {

		System.out.println("inside Saxophone constructor");
	}

	/**
	 * play method that prints some tesxt
	 */
	public void play() {

		System.out.println("inside Saxophone play");

	}

}
