/**
 *  Interface:  Performer 
 * 
 * Description: Interface that contains a abstract  performer method 
 * 
 * Date : 12/10/2020
 */


package com.ust.training.springExcercise;
/**
 * Interface that contains a abstract  performer method 
 * @author sanga
 *
 */
public interface Performer {
	
	public void perform();

}
