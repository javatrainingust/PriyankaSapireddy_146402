/**
 * Class:  springDemo 
 * 
 * Description: Class that contains main method to call all classes 
 * 
 * Date : 12/10/2020
 */


package com.ust.training.springExcercise;

import org.springframework.context.support.ClassPathXmlApplicationContext;
/**
 * Class that contains mainMethod
 * 
 * @author sanga
 *
 */


public class springDemo {
/**
 * Main Method
 * @param args
 */
	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		 
		Orgenizer orgenizer =  context.getBean("welcomeMsg",Orgenizer.class);
		
		orgenizer.sayGreetings();
   
		Singer singer =  context.getBean("singer",Singer.class);
		
		singer.perform();

	}

}
