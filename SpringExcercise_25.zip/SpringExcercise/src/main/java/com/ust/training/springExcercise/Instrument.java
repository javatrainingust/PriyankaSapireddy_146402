/**
 * Class: Instrument
 * 
 * Description: Instrument Interface with some abstract method 
 * 
 * Date: 12/10/2020
 * 
 */


package com.ust.training.springExcercise;

/**
 *  Instrument Interface with some abstract method play
 * 
 *
 */
public interface Instrument {
	
	/**
	 *  abstract method play
	 */
	
	public void play();

}
