/**
 * ClassName: SpringConfig2
 * 
 * Description: SpringConfig is for explaining java configuration 
 * 
 * Date:13/10/2020
 */

package com.ust.training.springExcercise;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
/**
 * SpringConfig is for explaining java configuration 
 * @author sanga
 *
 */
@Configuration
public class SpringConfig2 {

@Bean(name ="Piyano")
	
	public Instrumentalist getInstrumentalist() {
		
      System.out.println("inside getInstrumentalist() method of SpringConfig class");
		
      Instrumentalist instrumentalist = new Instrumentalist();
		
      instrumentalist.setSaxophone(getSaxophones());
		
		return instrumentalist;
		
	}
	@Bean()
	public  Saxophone getSaxophones() {
		System.out.println("inside getSaxophones() method of SpringConfig class");
		
	   Saxophone saxophones = new Saxophone();
		return saxophones;
		
	}
}
