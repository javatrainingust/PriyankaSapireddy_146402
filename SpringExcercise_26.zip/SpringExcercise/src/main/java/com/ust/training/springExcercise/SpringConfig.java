/**
 * ClassName: SpringConfig
 * 
 * Description: SpringConfig is for explaining java configuration 
 * 
 * Date:13/10/2020
 */
package com.ust.training.springExcercise;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class SpringConfig {
	
	@Bean(name ="welcomeMsg")
	
	public Orgenizer getOrgenizer() {
		
   System.out.println("inside getOrgenizer() method of SpringConfig class");
		
   Orgenizer orgenizer = new Orgenizer();
		
		
   return orgenizer;
		
	}
	
		
	
	

}
