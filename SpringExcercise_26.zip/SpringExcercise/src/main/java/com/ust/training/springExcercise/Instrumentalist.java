/**
 * Class: Instrumentalist 
 * 
 * Description: Instrumentalist  class that implements  Performer Imterface
 * 
 * Date : 12/10/2020
 */

package com.ust.training.springExcercise;
/**
 * Instrumentalist class that implements Performer Imterface
 * 
 * @author sanga
 *
 */

public class Instrumentalist implements Performer {
	
	Saxophone Saxophone;

	

	/**
	 * generated getter and setters for Saxophone
	 * 
	 * @return
	 */

	

	public Saxophone getSaxophone() {
		return Saxophone;
	}

	public void setSaxophone(Saxophone saxophone) {
		Saxophone = saxophone;
	}

	

	

	public Instrumentalist() {

		System.out.println("inside Instrumentalist constructor");
	}

	/**
	 * method Instrumentalist that prints some msg and 
	 * 
	 */
	public void perform() {
		// TODO Auto-generated method stub
		Saxophone.play();
		System.out.println(" Instrumentalist  is performing ----------- ");

	}

}
