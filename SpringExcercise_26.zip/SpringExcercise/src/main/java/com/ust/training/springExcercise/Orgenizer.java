/**
 * Class:  Orgenizer 
 * 
 * Description: Class that contains sayGreetings method  for greeting 
 * 
 * Date : 12/10/2020
 */

package com.ust.training.springExcercise;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Class that contains sayGreetings method for greeting
 * 
 * @author sanga
 *
 */

public class Orgenizer {

	
	/**
	 * Constructor
	 */
	public Orgenizer() {

		System.out.println("inside the Orgenizer default constructer");

	}

	/**
	 * sayGreetings method to print the greeting message
	 */
	public void sayGreetings() {
		System.out.println("Welcome to the talent competion");
		

	}

}
