/**
 * Class:  MainMethodForEx3 
 * 
 * Description: Class that contains main method to call all classes and interface
 * 
 * Date : 12/10/2020
 */

package com.ust.training.springExcercise;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Class that contains main method to call all classes and interface
 * 
 * @author sanga
 *
 */
public class MainMethodForEx3 {

	/**
	 * Main Method
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig2.class);
		 

		Instrumentalist instrumentalist = context.getBean("Piyano", Instrumentalist.class);

		instrumentalist.perform();

	}

}
