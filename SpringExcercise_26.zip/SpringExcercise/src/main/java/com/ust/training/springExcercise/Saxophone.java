/**
 * Class: Saxophone
 * 
 * Description:  Saxophone class that implements  Instrument Interface
 * 
 * Date: 12/10/2020
 * 
 */

package com.ust.training.springExcercise;

import org.springframework.stereotype.Component;

/**
 * Saxophone class that implements Instrument Interface
 * 
 * @author sanga
 *
 */
@Component
public class Saxophone implements Instrument {
	/**
	 * Saxophone default constructor
	 */
	public Saxophone() {

		System.out.println("inside Saxophone constructor");
	}

	/**
	 * play method that prints some tesxt
	 */
	public void play() {

		System.out.println(" Saxophone  is playing -----------");

	}

}
