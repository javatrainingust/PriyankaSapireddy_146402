package com.training.ust;

public interface Test {
	
	public void test();
}
