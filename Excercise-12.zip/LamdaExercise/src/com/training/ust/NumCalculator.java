package com.training.ust;

public interface NumCalculator {
	public int getValue(int a, int b);

}
