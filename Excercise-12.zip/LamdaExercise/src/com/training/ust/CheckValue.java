package com.training.ust;

public interface CheckValue {
	
	public boolean check(int n);

}
