package com.training.ust;

public interface DisplayResult {
	
	public void display(String s);

}
