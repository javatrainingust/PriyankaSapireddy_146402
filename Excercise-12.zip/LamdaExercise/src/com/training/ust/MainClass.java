package com.training.ust;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		CheckValue isEven = (n) -> n%2==0;
		System.out.println(" 10 is even number=   "+isEven.check(10));
		
		NumCalculator numc =(a,b)-> a+b;
		System.out.println("addition of A and B is =  "+numc.getValue(4, 5));
		
		DisplayResult dr =(s) -> System.out.println("Display string is =  "+s);
		dr.display("Hello All");
		
		Test t = () -> System.out.println("This is test interface");	
		t.test();
		
}

}
