/**
 * className: excercise_3
 * 
 * Description: Class that implements supplier interface using lamda Expression
 * 
 * Date:10/8/2020
 **/



package com.ust.training.funcInterfaceExcercise;

import java.util.function.Function;

/**
 * Class that convert a string to upper case. 
 * */
public class Excercise_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Function<String, String> capital= (n)->n.toUpperCase();
		System.out.println(capital.apply("convert to upper case"));

	}

}
