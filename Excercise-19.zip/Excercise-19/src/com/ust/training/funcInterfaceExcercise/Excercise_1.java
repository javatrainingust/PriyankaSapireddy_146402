/**
 * className: excercise_1
 * 
 * Description: Class that implements supplier interface using lamda Expression
 * 
 * Date:10/8/2020
 **/


package com.ust.training.funcInterfaceExcercise;

import java.util.function.Supplier;

/**
 * This class contains a method which generating random number using Supplier functional interface.
 * */

public class Excercise_1 {
	
	public static void main(String[] args) {
		
	
		Supplier<Double> number=()->Math.random();
		System.out.println(number.get());
		
		
		
	}
	
	
	
	

}
