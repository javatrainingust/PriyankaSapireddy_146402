/**
 * className: excercise_2
 * 
 * Description: Class that implements supplier interface using lamda Expression
 * 
 * Date:10/8/2020
 **/



package com.ust.training.funcInterfaceExcercise;

import java.util.function.Consumer;

/**
 * This class contains a method which will convert each  string to upper case and prints it.
 * */

public class Excercise_2 {
	
	/**
	 * Main method  a consumer interface that converting a string to upper case. 
	 * */
	
public static void main(String[] args) {
		
		Consumer<String> string= (n)-> System.out.println(n.toUpperCase());
		
		string.accept("this is priyanka");
	}
	
	

}
