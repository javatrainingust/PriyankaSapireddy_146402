/**
 * className: excercise_3
 * 
 * Description: Class that implements supplier interface using lamda Expression
 * 
 * Date:10/8/2020
 **/



package com.ust.training.funcInterfaceExcercise;

import java.util.function.Predicate;

/**
 * A class which is for checking a number greater than 50 or not. 
 * */

public class Excercise_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Predicate<Integer> isGreater= (n)->n>50;
		
		System.out.println(isGreater.test(10));
		
		
	}

}
