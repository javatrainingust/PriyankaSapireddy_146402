package com.training.model;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

class LoanAccountTest {

	@Test
	void testCalculate_emi() {
		
		int expected = 10000;
		
		LoanAccount la = new LoanAccount();
		
		float actual = la.calculate_emi();
		
		assertEquals(expected,actual);
		
		
	}

}
