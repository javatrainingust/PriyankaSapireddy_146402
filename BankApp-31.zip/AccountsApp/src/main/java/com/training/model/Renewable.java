package com.training.model;

import java.util.Calendar;

public interface Renewable {
	
	public Calendar autoRenewable(int ternure);

}
