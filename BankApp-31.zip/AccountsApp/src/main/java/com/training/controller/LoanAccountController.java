/**
 * Class Name: LoanAccountController
 * 
 * Description: Class which is used give the http request to server by using @Controller and @RequestMapping
 * 
 * Date:15/10/2020
 */


package com.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.training.model.LoanAccount;
import com.training.model.SbAccount;
import com.training.service.LoanAccountService;
import com.training.service.SbAccountService;
/**
 * Class which is used give the http request to server by using @Controller and @RequestMapping
 * @author sanga
 *
 */
@Controller
public class LoanAccountController {
	

	@Autowired
	private LoanAccountService service;
	
	
	@RequestMapping("/loanAccounts")
	
	public String getAllLoanAccounts(Model model){
		
		System.out.println("Inside controller getAllLoanAccounts ");
		
		List<LoanAccount> employeeList = service.getAllLoanAccountdetails();
		
		model.addAttribute("loanAccounts",employeeList );
		
		
		return "loanAccountList";
		
	}
}


