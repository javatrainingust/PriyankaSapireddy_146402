/**
 * ClassNAme: FdAccountAddAccount
 * 
 * Description: class for getting outputs
 * 
 * Date-08-10-2020
 */


package com.training.service;

import com.training.model.FdAccount;
/**
 * class for getting outputs with main methods
 * 
 *
 */
public class FdAccountAddAccount {
	
	public static void main(String[] args) {
		
		FdAccountService service = new FdAccountService();
		
		service.addFdAccount(new FdAccount(1234, "Priyanka", 10000, 4, 0.2f));
		service.addFdAccount(new FdAccount(1235, "Sujatha", 90000, 4, 0.3f));
		service.addFdAccount(new FdAccount(1235, "Sujatha", 90000, 4, 0.3f));
		
		System.out.println("Printing all Accounts");	
		service.getAllFdaAccountdetails();
		System.out.println("---------------------------------------------");	
		
        service.updateFdAccount((new FdAccount(1235, "Sujatha", 100000, 4, 0.3f)));
		
		System.out.println("Printing all updated Accounts");	
		
		service.getAllFdaAccountdetails();
		
	}

}
