/***
 * ClassName:CurrentAccountService
 * 
 * Description:Service class for the implementation of CurrentAccountDaoImplementation
 * 
 * Date-06-10-2020
 */



package com.training.service;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.dataaccess.CurrentAccountDAO;
import com.training.dataaccess.CurrentAccountDAOImpl;
import com.training.dataaccess.FdAccountDAOImpl;
import com.training.dataaccess.FdaaccountDao;
import com.training.model.CurrentAccount;
import com.training.model.FdAccount;


/**
 * This class contains methods get all current account, get one current account by account number,
 * delete one current account, get all current account sorted by name, get all current account sorted by Overdraft Limit
 * 
 */
@Service
public class CurrentAccountService {
	
	@Autowired
   private   CurrentAccountDAO  accountDao1 ;
		
		
	 public CurrentAccountService() {
		 
		 accountDao1 = new  CurrentAccountDAOImpl();
		 
	 }
	 /**Calling the getting getAllCurrentAccounttdetails method in implementation class*/
	 
	 public List<CurrentAccount> getAllCurrentAccounttdetails() {
		 
		 
		 List currentAccountList = accountDao1.getAllCurrentAccounttdetails();
			
			
			Iterator<CurrentAccount> iterator = currentAccountList.iterator();
			
			while(iterator.hasNext()){
				
				CurrentAccount pe = iterator.next();
				
				System.out.println("Customer Account Number   " +pe.getAccountNo());
				System.out.println("Customer Account holder name  "+pe.getAccountHolderName());
				System.out.println("Customer Account balance  "+pe.getBalanceAmount());
				System.out.println("Customer Account  OverDraftLimit  "+pe.getOverDraftLimit());
				
				}			
				
				
			return currentAccountList;
			
			
			
		}
	 
	 /**Calling the getCurrentAccountByAccountNumber method in impl class by passing accountnum*/
	 
	 public CurrentAccount  getCurrentAccountByAccountNumber(int accountNo) {
		 
		 
		 CurrentAccount pe = accountDao1.getCurrentAccountByAccountNumber( accountNo) ;
			
			

			System.out.println("Customer Account Number   " +pe.getAccountNo());
			System.out.println("Customer Account holder name  "+pe.getAccountHolderName());
			System.out.println("Customer Account balance  "+pe.getBalanceAmount());
			
			System.out.println("Customer Account OverDraftLimit  "+pe.getOverDraftLimit());
			
			return pe;
			
		 }
	 
	 /**Calling Delete method   by passing accountnum*/
	 public void deleteFdAccount(int accountNo) {
		 
		 
		 accountDao1.deleteCurrentAccount( accountNo);
		 
		 
		 }
	 
	 public List<CurrentAccount> 	getAllCurrentAccountSortedByNames(){
		 
		 List<CurrentAccount> currentAccountList = accountDao1.getAllCurrentAccounttdetails();
			
			//Collections.sort(currentAccountList);
		 
		    Stream<CurrentAccount> currentAccountStream = currentAccountList.stream();
			
			Stream<CurrentAccount> sortedStream = currentAccountStream.sorted();
			
			List sortedcurrentAccountListList = sortedStream.collect(Collectors.toList());
			
			Iterator<CurrentAccount> iterator = sortedcurrentAccountListList.iterator();
			
			while(iterator.hasNext()){
				
				CurrentAccount pe = iterator.next();
				
				System.out.println("Customer Account Number   " +pe.getAccountNo());
				System.out.println("Customer Account holder name  "+pe.getAccountHolderName());
				System.out.println("Customer Account balance  "+pe.getBalanceAmount());
				
				System.out.println("Customer Account OverDraftLimit  "+pe.getOverDraftLimit());
			}
			
			return  currentAccountList;
		 
	
		 }
	 
	 public List<CurrentAccount> getAllCurrentAccountSortedByOverDraftLimit(){
			
			
		 List<CurrentAccount> currentAccountList = accountDao1.getAllCurrentAccounttdetails();
			
			//Collections.sort(currentAccountList,new CurrentaccountOverDraftLimitComparator());
			
		  Stream<CurrentAccount> currentAccountStream = currentAccountList.stream();
			
			
			Stream<CurrentAccount> sortedStream = currentAccountStream.sorted(new CurrentaccountOverDraftLimitComparator());
			
			List sortedcurrentAccountListList = sortedStream.collect(Collectors.toList());
			
			Iterator<CurrentAccount> iterator = sortedcurrentAccountListList.iterator();
			
			while(iterator.hasNext()){
				
				CurrentAccount pe = iterator.next();
				
				System.out.println("Customer Account Number   " +pe.getAccountNo());
				System.out.println("Customer Account holder name  "+pe.getAccountHolderName());
				System.out.println("Customer Account balance  "+pe.getBalanceAmount());
				
				System.out.println("Customer Account OverDraftLimit  "+pe.getOverDraftLimit());
				
				}			
			
			
			
			return currentAccountList;
		}
	 
		public void addCurrentAccount(CurrentAccount currentAccount) {
			
           boolean isAdded = accountDao1.addCurrentAccount(currentAccount);
			
			if(!isAdded){
				
				System.out.println("The Account already exist");
			}
			else{
				System.out.println("The Account successfully added");
		 
		 
	 }
			
			
		}
		public void updateCurrentAccount(CurrentAccount currentAccount) {
			
			accountDao1.updateCurrentAccount(currentAccount);
		}
	 
	 

}
