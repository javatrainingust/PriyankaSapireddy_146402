/*
 * Classname: LoanAccount
 * 
 * Description: a sub class that extends Account 
 * 
 * Date: 30/09/2020
 * 
 * 
 */

package com.training.model;

public class LoanAccount extends Account{
	
	private  float emi;
	private  float loanOutstanding;
	private   int  ternure ;
	

	/* creating non-parameterized and parameterized constructors */
	 public LoanAccount() {
			
		 System.out.println("Inside LoanAccount non-paramenterised constructor");
	}
	
	public LoanAccount(String accountNo,String accountHolderName,float balanceAmount,float emi,float loanOutstanding,int ternure) {
		
		super(accountNo, accountHolderName, balanceAmount);
		 System.out.println("Inside LoanAccount paramenterised constructor");
	}
	
	public float getEmi() {
		return emi;
	}
	public void setEmi(float emi) {
		this.emi = emi;
	}
	public float getLoanOutstanding() {
		return loanOutstanding;
	}
	public void setLoanOutstanding(float loanOutstanding) {
		this.loanOutstanding = loanOutstanding;
	}
	public int getTernure() {
		return ternure;
	}
	public void setTernure(int ternure) {
		this.ternure = ternure;
	}
	
	public float calculate_emi() {
		float emi;
		float p= this.getBalanceAmount();
		int n= 1;
		
		emi = p/n;
		
		return this.emi = emi;
		
		
		
	}
	
	
	
	
	

}
