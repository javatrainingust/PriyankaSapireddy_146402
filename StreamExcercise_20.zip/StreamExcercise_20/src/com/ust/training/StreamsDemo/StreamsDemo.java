/**
 * ClassName: StreamDemo
 * 
 * Description: Class that create Stream List of student names and count the number of students
 * 
 * date:10/9/2020
 */


package com.ust.training.StreamsDemo;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
/**
 * Class that create Stream List of student names and count the number of students
 *
 *
 */
public class StreamsDemo {

	/**
	 * Main method
	 * @param args
	 */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> studentNames = new ArrayList<String>();
		studentNames.add("Vinod");
		studentNames.add("Suresh");
		studentNames.add("John");
		studentNames.add("Roshan");
		
		Stream<String> studentStream = studentNames.stream();
		
		long noOfStudents = studentStream.count();
		
		System.out.println(noOfStudents);
		
		
	}

}
