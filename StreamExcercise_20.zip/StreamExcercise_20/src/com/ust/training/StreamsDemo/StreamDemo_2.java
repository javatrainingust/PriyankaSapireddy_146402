/**
 * ClassName: StreamDemo_2
 * 
 * Description: Class that create Stream array of student names and count the number of students
 * 
 * date:10/9/2020
 */




package com.ust.training.StreamsDemo;

import java.util.Arrays;
import java.util.stream.Stream;
/**
 * Class that create Stream array of student names and count the number of students
 * @author sanga
 *
 */
public class StreamDemo_2 {
	/**
	 * Main method
	 * @param args
	 */
	public static void main(String[] args) {
		
		String[] studentArray = {"Vinod","Suresh","John","Roshan"};
		
		Stream<String> studentSream = Arrays.stream(studentArray);
		
		long studentCount = studentSream.count();
		
		System.out.println(studentCount);
		
	}

}
