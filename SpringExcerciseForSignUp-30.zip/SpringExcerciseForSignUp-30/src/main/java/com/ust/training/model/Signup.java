/**
 * ClassName: SignUp
 * 
 * Description: Class that contains  private attributes 
 * 
 * Date: 15/10/2020
 */

package com.ust.training.model;
/**
 * Class that contains  private attributes  ang generated public getters and setters 
 * 
 *
 */
public class Signup {


	private String userName;
	private String userId;
	private String password;
	private String confirmPassword;
	
	/**
	 * getter for username
	 * */
	public String getUserName() {
		return userName;
	}
	/**
	 * Setter for username
	 * */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * getter for user id
	 * */
	public String getUserId() {
		return userId;
	}
	/**
	 * setter for user id
	 * */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	/**
	 * getter for password
	 * */
	public String getPassword() {
		return password;
	}
	/**
	 * setter for password
	 * */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * getter for password
	 * */
	public String getConfirmPassword() {
		return confirmPassword;
	}
	/**
	 * setter for password
	 * */
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	
	
}
