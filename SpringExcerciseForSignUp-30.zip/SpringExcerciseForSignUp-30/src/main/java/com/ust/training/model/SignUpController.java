/**
 * ClassName: SignUp
 * 
 * Description: This is controller class
 * 
 * Date: 15/10/2020
 */


package com.ust.training.model;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;



/**
 * This is controller class
 * */
@Controller
@RequestMapping("/signup")
public class SignUpController {
	
	/**
	 * This method is to show form
	 * */
	@RequestMapping("/showForm")
	public String showForm(Model model) {
		Signup signup= new Signup();
		
		signup.setUserName("ramesh");
		signup.setUserId("1234");
		model.addAttribute("signup", signup);
		return "signup";
	}
	/**
	 * This method will process the form data and returns to a jsp page using model atribute. 
	 * */
	@RequestMapping("/processForm")
	public String processForm(@ModelAttribute("signup") Signup signup) {
		System.out.println(signup.getUserName());
		return "confirmSignup";
	}
}
