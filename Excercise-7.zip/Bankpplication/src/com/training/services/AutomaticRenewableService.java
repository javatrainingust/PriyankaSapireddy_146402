package com.training.services;

import com.training.model.FdAccount;
import com.training.model.Renewable;

public class AutomaticRenewableService {
	
	public static void main(String[] args) {
	
	Renewable r = new FdAccount();
	r.autoRenewable(6);
	}

}
