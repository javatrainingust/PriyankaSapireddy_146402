package com.training.services;


import com.training.model.CurrentAccount;
import com.training.model.FdAccount;
import com.training.model.LoanAccount;
import com.training.model.SbAccount;
import com.training.util.Icalculator;
import com.training.util.InterestCalculator;


public class WithdrawService {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		FdAccount  fdacc = new  FdAccount();
		
		  fdacc.setAccountNo("App123456634");
		  fdacc.setIfscCode("APP000561");
		  fdacc.setAccountHolderName("Priyanka");
		 
		  fdacc.withDrawAmount(2000);
		  fdacc.autoRenewable(2);
		  fdacc.setRate(.5f);
		  fdacc.setTenure(1);
		  
		
		  Icalculator calculator = new InterestCalculator();
		  
		   fdacc.calculateInterest(calculator);
		
		  CurrentAccount cac = new CurrentAccount();
		   
		  cac.setAccountNo("App123456634");
		  cac.setIfscCode("APP000561");
		  cac.setAccountHolderName("Priyanka");
		  cac.setOverDraftLimit(100000);
		  cac.isLimitExceed(70000);
	
		
		LoanAccount lac = new LoanAccount();
		
		   lac.setAccountNo("App123456632");
		   lac.setIfscCode("APP000561");
		   lac.setAccountHolderName("Priya");
		   lac.setEmi(1295);
		   lac.setLoanOutstanding(2000);
		   lac.setTernure(2);
		
		
		SbAccount scac = new SbAccount();
		
		  scac.setAccountNo("App123456634");
		  scac.setIfscCode("APP000561");
		  scac.setAccountHolderName("Priyanka");
		  scac.setRate(0.7f);
		  
		  scac.calculateInterest();
		
		
		
		
		
	}

}
