package com.training.model;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.util.Calendar;

import com.training.util.Icalculator;
import com.training.util.InterestCalculator;


public class FdAccount extends Account implements Renewable{
	
	private int tenure ;
	
	private boolean autoRenewal = true;
	
	private float rate;
	
	public float getRate() {
		return rate;
	}
	
	public void setRate(float rate) {
		this.rate = rate;
	}
	
	private Calendar maturity_date = Calendar.getInstance();
	//private InterestCalculator clacs = new InterestCalculator();
	
	
	public int getTenure() {
		return tenure;
	}
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	public boolean isAutoRenewal() {
		return autoRenewal;
	}
	public void setAutoRenewal(boolean autoRenewal) {
		this.autoRenewal = autoRenewal;
	}

	
    public void calculateInterest(Icalculator calculator) {
		
		float interesrt = calculator.calculateInterest(this.getBalanceAmount() ,this.rate);
		
		System.out.println("your FDAccount will have RS "+interesrt+ " as interest  with rate "+this.rate);
		
	}


	@Override
	public void autoRenewable(int ternure) {
		
		DateFormat df = new SimpleDateFormat("dd/MM/yy");
		Calendar calobj = Calendar.getInstance();
		this.maturity_date.set(2020, 8, 29);
		if(this.autoRenewal) {
			
			if (df.format(this.maturity_date.getTime()).compareTo(df.format(calobj.getTime()))==0) {
				
				this.maturity_date.add(Calendar.YEAR,tenure);
				System.out.println("Your FD account got automatically renewed. new maturity date is"+this.maturity_date.getTime());
			 
			}
		
		 }
	

	}
}
