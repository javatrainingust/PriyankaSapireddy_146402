package com.training.model;

import com.training.util.InterestCalculator;

public class SbAccount extends Account {
	
	
	private float rate;
	private int time;
	private InterestCalculator clacs = new InterestCalculator();
	
	public float getRate() {
		return rate;
	}
	public void setRate(float rate) {
		this.rate = rate;
	}
	public int getTime() {
		return time;
	}
	public void setTime(int time) {
		this.time = time;
	}
	
	public void calculateInterest() {
		
		float interesrt = this.clacs.calculateInterest(this.getBalanceAmount(),this.rate);
		System.out.println("your SBAccount will have RS "+interesrt+ " as interest  with rate "+this.rate);
		
	}
	

	
	

}
