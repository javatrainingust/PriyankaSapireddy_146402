package com.training.model;

import com.training.util.Icalculator;

public class Account {
	
	private String accountNo;
	private String ifscCode;
	private String accountHolderName;
	private float balanceAmount = 10000f ;
	
	public String getAccountNo() {
		return accountNo;
	}
	
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	
	public String getIfscCode() {
		return ifscCode;
	}
	
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	
	public String getAccountHolderName() {
		return accountHolderName;
	}
	
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	
	public float getBalanceAmount() {
		return balanceAmount;
	}
	
	
	    public void  withDrawAmount( int withdrawAmount) {
		this.balanceAmount =balanceAmount -withdrawAmount;
		System.out.println("Available balance in your savings account =" +this.balanceAmount);
	}
	    
	    
	  public void calculateInterest(Icalculator calculator) {
			
		 System.out.println("inside base class");
	  }
	  
	  @Override
		public String toString() {
			return "Account [accountNumber=" +  accountNo + ", accountHolderName=" + accountHolderName + "]";
		}
	    
	    
	   
	
}
