package com.training.model;

public class CurrentAccount extends Account {
	
	private float overDraftLimit ;
	
   private boolean overdraftLimitExceed ;

	public boolean isOverdraftLimitExceed() {
		return overdraftLimitExceed;
	}

	public void setOverdraftLimitExceed(boolean overdraftLimitExceed) {
		overdraftLimitExceed = overdraftLimitExceed;
	}

	public float getOverDraftLimit() {
		return overDraftLimit;
	}

	public void setOverDraftLimit(float overDraftLimit) {
		this.overDraftLimit = overDraftLimit;
	}
	
	public void isLimitExceed(float expenditure) {
		if(expenditure == overDraftLimit) {
			this.overdraftLimitExceed = true;
			
		}
		else {
			 this.overdraftLimitExceed =  false ;
		}
		
		System.out.println(" overdraft limit exceeded ?  " +this.isOverdraftLimitExceed());
	}

}
