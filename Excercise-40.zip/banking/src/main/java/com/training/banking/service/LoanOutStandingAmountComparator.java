/**
 * ClassName:  LoanOutStandingAmountComparator
 * 
 * Description:  for  comparing process 
 * 
 * Date-06-10-2020
 * */

package com.training.banking.service;

import java.util.Comparator;

import com.training.banking.model.LoanAccount;
/**
 * Class  LoanOutStandingAmountComparatorr  for comparing  the iutputs
 * 
 */
public class LoanOutStandingAmountComparator  implements Comparator<LoanAccount>{

	public int compare(LoanAccount o1, LoanAccount o2) {
		// TODO Auto-generated method stub
		return  (int) (o1.getLoanOutstanding()-o2.getLoanOutstanding());
	}

}
