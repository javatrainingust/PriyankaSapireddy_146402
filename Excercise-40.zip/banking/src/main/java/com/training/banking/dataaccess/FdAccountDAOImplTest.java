/**
 * ClassName:FdAccountDAOImplTest
 * 
 * Description:JuintTesting
 * 
 * Date-06-10-2020
 * */


package com.training.banking.dataaccess;

import static org.junit.Assert.assertEquals;


import java.util.List;

import org.junit.Test;
import org.springframework.stereotype.Repository;

import com.training.banking.model.CurrentAccount;
import com.training.banking.model.FdAccount;


class FdAccountDAOImplTest {
	
	FdaaccountDao dao = new FdAccountDAOImpl();
	FdAccount fd = new FdAccount();	

	@Test
	void testGetAllFdaAccountdetails() {
		
		int expected=3;
		List<FdAccount> actual=dao.getAllFdaAccountdetails();
		assertEquals(expected,actual.size());
		
	}

	@Test
	void testGetFdAccountByAccountNumber() {
		 
		    String expectedValue="Priyanka";
			
			fd=dao.getFdAccountByAccountNumber(1234);
			
			String actualValue=fd.getAccountHolderName();
			
			assertEquals(expectedValue,actualValue);
			
	}

	@Test
	void testDeleteFdAccount() {
		
		int expectedSize=2;
		dao.deleteFdAccount(1235);
		List<FdAccount> actual=dao.getAllFdaAccountdetails();
		assertEquals(expectedSize, actual.size());
	}
	}


