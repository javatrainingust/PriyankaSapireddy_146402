/***
 * ClassName:SbAccountService
 * 
 * Description:Service class for the implementation of SbAccountDaoImplementation
 * 
 * Date-06-10-2020
 */


package com.training.banking.service;

import java.util.Collections;

import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.banking.dataaccess.LoanAccountDAO;
import com.training.banking.dataaccess.LoanAccountDAOImpl;
import com.training.banking.dataaccess.SbAccountDAO;
import com.training.banking.dataaccess.SbAccountDAOImpl;
import com.training.banking.model.CurrentAccount;
import com.training.banking.model.FdAccount;
import com.training.banking.model.LoanAccount;
import com.training.banking.model.SbAccount;
@Service
public class SbAccountService {
	@Autowired
	private  SbAccountDAO accountDao ;
	  
	  /**object creation using constructors*/
		
	  public SbAccountService() {
		 
		 accountDao = new  SbAccountDAOImpl();
		 
	 }
	  /**Calling the getting getAllSbAccountdetails method in implementation class*/
	  
	 public List<SbAccount > getAllSbAccountdetails() {
		 
		 
		 List sbAccountList = accountDao.getAllSbAccountdetails();
			
			
			Iterator<SbAccount> iterator = sbAccountList.iterator();
			
			while(iterator.hasNext()){
				
				SbAccount pe = iterator.next();
				
				System.out.println("Customer Account Number   " +pe.getAccountNo());
				System.out.println("Customer Account holder name  "+pe.getAccountHolderName());
				System.out.println("Customer Account balance  "+pe.getBalanceAmount());
				System.out.println("Customer Account  Rate  "+pe. getRate());
				System.out.println("Customer Account Time  "+pe.getTime());
				
				
				}			
				
				
			return sbAccountList ;
			
			
			
		}
	 
	 /**Calling the method in impl class by passing accountnum*/
	 
	 public SbAccount  getSbAccountByAccountNumber(int accountNo) {
		 
		 
		 SbAccount pe = accountDao.getSbAccountByAccountNumber(accountNo);
			
			

			System.out.println("Customer Account Number   " +pe.getAccountNo());
			System.out.println("Customer Account holder name  "+pe.getAccountHolderName());
			System.out.println("Customer Account balance  "+pe.getBalanceAmount());
			System.out.println("Customer Account  Rate  "+pe. getRate());
			System.out.println("Customer Account Time  "+pe.getTime());
			
			return pe;
			
		 }
	 
	 /**Calling Delete method   by passing accountnum*/
	 public void deleteLoanAccount(int accountNo) {
		 
		 
		 accountDao.deleteSbAccount( accountNo);
		 
	 }
	 
	 
public List<SbAccount> 	getAllSbAccountSortedByNames(){
		 
		 List<SbAccount> sbAccountList = accountDao.getAllSbAccountdetails();
			
			//Collections.sort(sbAccountList);
		    
		 Stream<SbAccount> sbAccountStream = sbAccountList.stream();
			
			Stream<SbAccount> sortedStream = sbAccountStream.sorted();
			
			List sortedsbAccountListList = sortedStream.collect(Collectors.toList());
			
			
			
			Iterator<SbAccount> iterator = sortedsbAccountListList.iterator();
			
			while(iterator.hasNext()){
				
				SbAccount pe = iterator.next();
				
				System.out.println("Customer Account Number   " +pe.getAccountNo());
				System.out.println("Customer Account holder name  "+pe.getAccountHolderName());
				System.out.println("Customer Account balance  "+pe.getBalanceAmount());
				System.out.println("Customer Account  Rate  "+pe. getRate());
				System.out.println("Customer Account Time  "+pe.getTime());
			}
			
			return  sbAccountList;
		 
	
		 }
	 
	 public List<SbAccount> getAllSbAccountSortedByBalance(){
			
			
		 List<SbAccount> sbAccountList = accountDao.getAllSbAccountdetails();
			
			//Collections.sort(sbAccountList,new SbBalanceComparator());
		  
		 Stream<SbAccount> sbAccountStream = sbAccountList.stream();
			
			Stream<SbAccount> sortedStream = sbAccountStream.sorted(new SbBalanceComparator());
			
			List sortedsbAccountListList = sortedStream.collect(Collectors.toList());
			
			
			
			Iterator<SbAccount> iterator = sortedsbAccountListList.iterator();
			
			while(iterator.hasNext()){
				
				SbAccount pe = iterator.next();
				
				System.out.println("Customer Account Number   " +pe.getAccountNo());
				System.out.println("Customer Account holder name  "+pe.getAccountHolderName());
				System.out.println("Customer Account balance  "+pe.getBalanceAmount());
				System.out.println("Customer Account  Rate  "+pe. getRate());
				System.out.println("Customer Account Time  "+pe.getTime());
				}			
			
			
			
			return sbAccountList;
		}
	 
	 public void addSbAccount(SbAccount sbAccount) {
		 
		 boolean isAdded = accountDao.addSbAccount(sbAccount);
			
			if(!isAdded){
				
				System.out.println("The Account already exist");
			}
			else{
				System.out.println("The Account successfully added");
		 
		 
	 }
	 }
	 
			public void updateSbAccount(SbAccount sbAccount) {
				
				accountDao.updateSbAccount(sbAccount);
				
				
			}
				
				
			
		 
	 }
	 
	 
		 
	 
	 


