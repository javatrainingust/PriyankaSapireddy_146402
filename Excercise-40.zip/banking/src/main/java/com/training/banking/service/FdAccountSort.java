/**
 * ClassName:  FdAccountSort
 * 
 * Description:MainMethod  for accessing process 
 * 
 * Date-06-10-2020
 * */

package com.training.banking.service;
/**
 * class with MainMethod  for accessing process 
 * @author sanga
 *
 */
public class FdAccountSort {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		FdAccountService service =  new FdAccountService();
		System.out.println("printing all  accounts");
		
		service.getAllFdaAccountdetails();
		System.out.println("----------------------");
		System.out.println();
		System.out.println("Print accounts after sorting by Name");
		service.getAllFdAccountsSortedByNames();
		System.out.println("----------------------");
		System.out.println();
		System.out.println("Print accounts after sorting based on  balance");
		service.getAllFdAccountsSortedByBalance();
		

	}

}
