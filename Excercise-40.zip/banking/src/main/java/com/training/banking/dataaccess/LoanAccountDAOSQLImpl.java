/**
 * Class : LoanAccountDAOSQLImpl 
 * Description : LoanAccountDAOSQLImpl  class  that implements  LoanAccountDAO interface  serves as Repository
 * Date: 23/10/2020
 */


package com.training.banking.dataaccess;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.training.banking.model.LoanAccount;
import com.training.banking.model.SbAccount;

/**
 *  LoanAccountDAOSQLImpl  class  that implements  LoanAccountDAO interface  serves as Repository
 * @author sanga
 *
 */
@Repository
public class LoanAccountDAOSQLImpl implements LoanAccountDAO {

	private DataSource dataSource;

	private JdbcTemplate jdbcTemplateObject;
		
		@Autowired
		public void setDataSource(DataSource dataSource) {
			this.dataSource = dataSource;
			jdbcTemplateObject = new JdbcTemplate(dataSource);
		}
		
		/**
		 * getAllLoanAccountdetails method to get all accounts 
		 */
	public List<LoanAccount> getAllLoanAccountdetails() {
		String SQL = "SELECT * FROM banking.loanaccount";
		
	      List <LoanAccount> employees= jdbcTemplateObject.query(SQL, new LoanAccountMapper());
		
		return employees;
	}
/**
 * getLoanAccountByAccountNumber meythod is to access account by using accountNo
 */
	public LoanAccount getLoanAccountByAccountNumber(int accountNo) {
		String sql = "select * from banking.loanaccount where accountNo= ?";
		 
		LoanAccount employee = (LoanAccount) jdbcTemplateObject.queryForObject(
                sql, new Object[] { accountNo }, new LoanAccountMapper());
      
       return 	employee;	
	}

	/***
	 * deleteLoanAccount method is used to deleteLoanAccount 
	 */
	public void deleteLoanAccount(int accountNo) {
		 String query="delete from banking.loanaccount where accountNo ='"+accountNo+"' ";  
		 jdbcTemplateObject.update(query);  
	}
/**
 * addLoanAccount is used to addLoanAccount account
 */
	public boolean addLoanAccount(LoanAccount loanAccount) {
		String sql = "Insert into  banking.loanaccount" +
				 "(accountNo,accountHolderName,balanceAmount,emi,loanOutstanding,ternure) values(?,?,?,?,?,?)";
				

			  jdbcTemplateObject.update(sql, new Object[] { loanAccount.getAccountNo(),
					  loanAccount.getAccountHolderName(), loanAccount.getBalanceAmount(),
					  loanAccount.getEmi(),loanAccount.getLoanOutstanding(),loanAccount.getTernure()
			        });
				return true;
	}
/**
 * updateLoanAccount is used to update account
 */
	public void updateLoanAccount(LoanAccount loanAccount) {

		String query="update banking.loanaccount set accountNo'"+ loanAccount.getAccountNo()+"',"
				+ " accountHolderName ='"+loanAccount.getAccountHolderName()+"' where accountNo ='"+loanAccount.getAccountNo()+"' ";  
	    jdbcTemplateObject.update(query);  


	}

}
