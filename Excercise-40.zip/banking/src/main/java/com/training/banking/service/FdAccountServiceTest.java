/**
 * ClassNAme: FdAccountTest
 * 
 * Description: Test for FdAccountDaoImplementation
 * 
 * Date-08-10-2020
 */



package com.training.banking.service;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;

import com.training.banking.model.CurrentAccount;
import com.training.banking.model.FdAccount;

/**
 * Testing 2 methods in Implementation class
 * 
 * 1.AddCurrent Account
 * 
 * 2.UpdateCurrentAccount
 */

class FdAccountServiceTest {
	
	FdAccountService service = new FdAccountService();
	FdAccount fd = new FdAccount();

//	@Test
//	void testGetAllFdAccountsSortedByNames() {
//		
//       String expectedValue = "Karthika";
//		
//		List<FdAccount> fdAccount = service.getAllFdAccountsSortedByNames();
//		
//		String actualValue = fdAccount.get(0).getAccountHolderName();
//		
//		assertEquals(expectedValue, actualValue);
//		
//	}
//
//	@Test
//	void testGetAllFdAccountsSortedByBalance() {
//        String expectedValue = "Priyanka";
//		
//		List<FdAccount> fdAccount = service.getAllFdAccountsSortedByBalance();
//		
//		String actualValue = fdAccount.get(0).getAccountHolderName();
//		
//		assertEquals(expectedValue, actualValue);
//		
//		
//	}
	
	 @Test
		
		void testAddFdAccount() {
			int expectedSize = 2;
			service.addFdAccount(new FdAccount(1234, "Priyanka", 10000, 4, 0.2f));
			service.addFdAccount(new FdAccount(1235, "Sujatha", 90000, 4, 0.3f));
			List<FdAccount> actual = service.getAllFdaAccountdetails();
			assertEquals(expectedSize, actual.size());
			
		}
	     
	     
	     @Test
	 	
	 	void testUpdateFdAccount() {
	 		
	 		String  expectedValue = "Sujatha";
	 		
	 		service.updateFdAccount((new FdAccount(1235, "Sujatha", 100000, 4, 0.3f)));
	 		 
	 		fd = service. getFdAccountByAccountNumber(1235);
	 		
	 		String actualValue = fd.getAccountHolderName();
	 		
	 		assertEquals(expectedValue, actualValue);
	    	 
	    	
	    	 
	    
	 		
	 		
	 	}


}
