/***
 * ClassNAme:LoanAccountDaoImplementation
 * 
 * Description:Implementing LoanAccountDao
 * 
 * Date -06-10-2020
 */




package com.training.banking.dataaccess;

import java.util.ArrayList;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Repository;

import com.training.banking.model.FdAccount;
import com.training.banking.model.LoanAccount;
/**
 * class for getAllLoanAccountdetails by name,balance ,deleteLoanAccount ,adding, and updating
 *
 */

public class LoanAccountDAOImpl implements LoanAccountDAO {
	

	/*Adding to List invoking objects in constructors*/
	
	
	List loanAccountList;
	Set loanAccountSet;
	
	public LoanAccountDAOImpl() {
  
		
		loanAccountList =new ArrayList<LoanAccount>();
		loanAccountSet = new HashSet<LoanAccount>();
		
		
		  LoanAccount fdac1 = new LoanAccount(1234,"Priyanka",10000,1.2f,10000,3);
		  LoanAccount fdac2 = new LoanAccount(1235,"Sujatha",90000,1.4f,10000,2);
		  LoanAccount fdac3 = new LoanAccount(1236,"Karthika",130000,1.3f,10000,1);
		  
		  loanAccountList.add(fdac1); loanAccountList.add(fdac2);
		  loanAccountList.add(fdac3);
		 
		
		
	}

	// get all the  Accountdetails

	public List<LoanAccount> getAllLoanAccountdetails() {
		return loanAccountList;
		
		
	}
  
	// get Accountdetails based on AccountNumber
	
	public LoanAccount getLoanAccountByAccountNumber(int accountNo) {
		
		LoanAccount	   loanAccount = null;
		
	      Iterator<LoanAccount> iterator = loanAccountList.iterator();
			
			while(iterator.hasNext()){
				
				LoanAccount	  pe = iterator.next();
				
				if(pe.getAccountNo()==accountNo){
					
					loanAccount=pe;
				}
				
				
			}
				
			
			return loanAccount;
	}

	// deleting the  account based on accountNumber
	
	public void deleteLoanAccount(int accountNo) {
		// TODO Auto-generated method stub
		LoanAccount	   loanAccount = null;
		
		for(int i=0; i<loanAccountList.size(); i++){
			
			loanAccount =(LoanAccount)loanAccountList.get(i);
				
				if( loanAccount.getAccountNo()==accountNo){
					
					loanAccountList.remove(i);
					
				}
				
			}		

	}


	public boolean addLoanAccount(LoanAccount loanAccount) {
		
     boolean isAdded =  loanAccountSet.add(loanAccount);
		
		if(isAdded){
			loanAccountList.add(loanAccount);
			 
		}
		return isAdded;
	}


	public void updateLoanAccount(LoanAccount loanAccount) {
		
     Iterator iterator = loanAccountList.iterator();
		
		
		while(iterator.hasNext()){
			
			LoanAccount pe =(LoanAccount)iterator.next();
			
			if(pe.getAccountNo()==loanAccount.getAccountNo()){
				
				pe.setAccountHolderName(loanAccount.getAccountHolderName());
				pe.setEmi(loanAccount.getEmi());
				pe.setTernure(loanAccount.getTernure());
				pe.setBalanceAmount(loanAccount.getBalanceAmount());
				pe.setLoanOutstanding(loanAccount.getLoanOutstanding());
				
				
				
			}
			
		
	}

}
}
