/**
 * Class Name: LoanAccountController
 * 
 * Description: Class which is used give the http request to server by using @Controller and @RequestMapping
 * 
 * Date:15/10/2020
 */


package com.training.banking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.training.banking.model.FdAccount;
import com.training.banking.model.LoanAccount;
import com.training.banking.model.SbAccount;
import com.training.banking.service.LoanAccountService;
import com.training.banking.service.SbAccountService;
/**
 * Class which is used give the http request to server by using @Controller and @RequestMapping
 * 
 *
 */
@RestController
public class LoanAccountController {
	

	@Autowired
	private LoanAccountService service;
	
	/**
	 * getAllLoanAccounts to get All LoanAccounts
	 * @param model
	 * @return loanAccountList
	 */
	@GetMapping("/loanaccounts") 
	public List<LoanAccount> getAllLoanAccounts(){
		
		List<LoanAccount> employeeList = service.getAllLoanAccountdetails();
		return employeeList;
		
	}
	
     /**
	 * addAccount is to addLoanAccount
	 * @param pe
	 * @return "redirect:/loanAccounts"
	 */
	@PostMapping("/loanaccounts") 
	public LoanAccount addAccount(@RequestBody LoanAccount pe) {
		
		
		service.addLoanAccount(pe);
		
		return pe ;
		
	}
	/**
	 * updateLoanaccount is to updateLoanaccount
	 * @param pe
	 * @return "redirect:/loanAccounts"
	 */
	@PutMapping("/loanaccounts/{accountNo}")
	public LoanAccount updateLoanaccount(@PathVariable  int  accountNo,@RequestBody  LoanAccount pe) {
		
		
		service.updateLoanAccount(pe);
		
		return pe;
		
	}
		/**
		 * getaccount  method to getLoanAccountByAccountNumber
		 * @param accountNo
		 * @param model
		 * @return  to viewLoanAccount 
		 */
	@GetMapping("/loanaccounts/{accountNo}") 
	public LoanAccount getaccountByAccountNo(@PathVariable int accountNo) {
		
		
		LoanAccount pe = service.getLoanAccountByAccountNumber(accountNo);
		return  pe;
		
		
	}
	/**
	 * getAllLoanAccountsByName method that is used for getAllLoanAccountSortedByNames
	 * @param model
	 * @return  to loanAccountList
	 */
	@RequestMapping("/sortLoanAccounyByName")
	public String getAllLoanAccountsByName(Model model){
		
		System.out.println("Inside controller getAllLoanAccounts ");
		
		List<LoanAccount> employeeList = service.getAllLoanAccountSortedByNames();
		
		model.addAttribute("loanAccounts",employeeList );
		
		
		return "loanAccountList";
		
	}
	/**
	 * getAllLoanAccountsByBalance method that is ued for getAllLoanAccountSortedByLoanOutStandingAmount
	 * @param model
	 * @return  to loanAccountList
	 */
	
	@RequestMapping("/sortLoanAccounyByLoanOutStandings")
	public String getAllLoanAccountsByBalance(Model model){
		
		System.out.println("Inside controller getAllLoanAccounts ");
		
		List<LoanAccount> employeeList = service.getAllLoanAccountSortedByLoanOutStandingAmount();
		
		model.addAttribute("loanAccounts",employeeList );
		
		
		return "loanAccountList";
		
	}
	/**
	 * deleteLoanaccount is to deleteLoanAccount
	 * @param accountNo
	 * @param model
	 * @return "redirect:/loanAccounts"
	 */
	@DeleteMapping("/loanaccounts/{accountNo}") 

	public void deleteLoanaccount(@PathVariable int accountNo) {
		
		
		 service.deleteLoanAccount(accountNo);
		
		
		
		
		
		
		
	}
}


