/**
 * ClassName:LoanaccountDataRetriva
 * 
 * Description:MainMethod  for accessing process 
 * 
 * Date-06-10-2020
 * */




package com.training.banking.service;
/**
 *  class with MainMethod  for accessing process 
 * @author sanga
 *
 */
public class LoanaccountDataRetriv {
	
	/**
	 * Main method
	 * 
	 */
public static void main(String arg[]){
		
		LoanAccountService service = new LoanAccountService();
		
		      //retrieving all  accounts 
		
			    service.getAllLoanAccountdetails();
				
				System.out.println("----------------------------------");
				
				
				service.getLoanAccountByAccountNumber(1234);
				
				System.out.println("----------------------------------");
				System.out.println("after deleting one account");
				System.out.println("----------------------------------");
				
				service.deleteLoanAccount(1235);
				service.getAllLoanAccountdetails();
				
		
				
	
	}

}
