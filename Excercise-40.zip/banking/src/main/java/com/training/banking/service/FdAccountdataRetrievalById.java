/**
 * ClassName:FdAccountdataRetrivalById
 * 
 * Description:MainMethod  for accessing process 
 * 
 * Date-06-10-2020
 * */




package com.training.banking.service;
/**
 * class which contains main method for accessing the  outputs
 * @author sanga
 *
 */
public class FdAccountdataRetrievalById {
	
	/**
	 * Main method
	 * @param arg
	 */
	public static void main(String arg[]){
		
		FdAccountService service = new FdAccountService();
		
		      //retrieving all  accounts 
		
			    service.getAllFdaAccountdetails();
				
				System.out.println("----------------------------------");
				
				
				service.getFdAccountByAccountNumber(1234);
				
				System.out.println("----------------------------------");
				System.out.println("after deleting one account");
				System.out.println("----------------------------------");
				
				service.deleteFdAccount(1235);
				service.getAllFdaAccountdetails();
				
		
				
	
	}

}
