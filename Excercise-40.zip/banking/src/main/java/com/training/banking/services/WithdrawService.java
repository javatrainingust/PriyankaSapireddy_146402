/**
  * Classname: WithdrawService
 * 
 * Description: this is a  class for WithdrawService  to access the outputs
 * 
 * Date:30/09/2020
 * 
 */



package com.training.banking.services;


import com.training.banking.Exception.InsufficiantMoneyException;
import com.training.banking.model.CurrentAccount;
import com.training.banking.model.FdAccount;
import com.training.banking.model.LoanAccount;
import com.training.banking.model.SbAccount;
import com.training.banking.util.Icalculator;
import com.training.banking.util.InterestCalculator;

/**
 *   class   with main method for WithdrawService  to access the outputs
 * 
 *
 */
public class WithdrawService {
/***
 * Main Method
 * @param args
 */
	public static void main(String[] args) {
		
		
		
		SbAccount scac = new SbAccount(4567,"Priyanka",10000,0.7f,30);
		
		try {
			scac.withdrawMoney(15000);
		} catch (InsufficiantMoneyException e) {
			
			System.out.println("Dear cutomer, " +e);
		}
		
		  
		
		
		
		
		
		
	}

}
