/**
 * ClassName:SbAccountDAOImplTest
 * 
 * Description:JuintTesting
 * 
 * Date-06-10-2020
 * */



package com.training.dataaccess;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.training.model.CurrentAccount;
import com.training.model.SbAccount;

class SbAccountDAOImplTest {

	SbAccountDAO dao = new SbAccountDAOImpl();
	SbAccount sb = new SbAccount();

	@Test
	void testGetAllSbAccountdetails() {

		int expected = 3;
		List<SbAccount> actual = dao.getAllSbAccountdetails();
		assertEquals(expected, actual.size());

	}

	@Test
	void testGetSbAccountByAccountNumber() {

		String expectedValue = "Priyanka";

		sb = dao.getSbAccountByAccountNumber(1234);

		String actualValue = sb.getAccountHolderName();

		assertEquals(expectedValue, actualValue);

	}

	@Test
	void testDeleteSbAccount() {

		int expectedSize = 2;
		dao.deleteSbAccount(1235);
		List<SbAccount> actual = dao.getAllSbAccountdetails();
		assertEquals(expectedSize, actual.size());

	}

}
