/**
 * InterfaceName: SbAccountDao
 * 
 * Description:Interface for adding,retrieving,deleting details in currentAccount
 * 
 * Date -06-10-2020
 */




package com.training.dataaccess;

import java.util.List;

import com.training.model.LoanAccount;
import com.training.model.SbAccount;

public interface SbAccountDAO {
	
	
	public List<SbAccount > getAllSbAccountdetails();
	 
	public SbAccount  getSbAccountByAccountNumber(int accountNo);
	
	public void deleteSbAccount(int accountNo);


}
