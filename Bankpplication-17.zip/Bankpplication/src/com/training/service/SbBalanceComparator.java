package com.training.service;

import java.util.Comparator;

import com.training.model.CurrentAccount;
import com.training.model.SbAccount;

public class SbBalanceComparator  implements Comparator<SbAccount>  {

	@Override
	public int compare(SbAccount one, SbAccount two) {
		// TODO Auto-generated method stub
		return (int) (one.getBalanceAmount()-two.getBalanceAmount());
	}

}
