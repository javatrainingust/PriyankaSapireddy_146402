package com.training.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.training.model.FdAccount;
import com.training.model.SbAccount;

class SbAccountServiceTest {
	
	SbAccountService service = new SbAccountService();
	SbAccount account = new SbAccount();

	@Test
	void testGetAllSbAccountSortedByNames() {
		 String expectedValue = "Karthika";
			
			List<SbAccount> sbAccount = service.getAllSbAccountSortedByNames();
			
			String actualValue = sbAccount.get(0).getAccountHolderName();
			
			assertEquals(expectedValue, actualValue);
	}

	@Test
	void testGetAllSbAccountSortedByBalance() {
		 String expectedValue = "Priyanka";
			
			List<SbAccount> sbAccount = service.getAllSbAccountSortedByBalance();
			
			String actualValue = sbAccount.get(0).getAccountHolderName();
			
			assertEquals(expectedValue, actualValue);
	}

}
