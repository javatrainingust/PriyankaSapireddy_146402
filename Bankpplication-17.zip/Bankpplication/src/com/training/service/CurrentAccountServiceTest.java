package com.training.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.training.model.CurrentAccount;


class CurrentAccountServiceTest {
	
	 CurrentAccountService service = new  CurrentAccountService();
	 CurrentAccount fd = new CurrentAccount();
	
	 @Test
	void testGetAllCurrentAccountSortedByNames() {
		
		String expectedValue = "Karthika";
		
		List<CurrentAccount> currentAccount = service.getAllCurrentAccountSortedByNames();
		
		String actualValue = currentAccount.get(0).getAccountHolderName();
		
		assertEquals(expectedValue, actualValue);
	}

	@Test
	void testGetAllCurrentAccountSortedByOverDraftLimit() {
		
       String expectedValue = "Priyanka";
		
		List<CurrentAccount> currentAccount = service.getAllCurrentAccountSortedByOverDraftLimit();
		
		String actualValue = currentAccount.get(0).getAccountHolderName();
		
		assertEquals(expectedValue, actualValue);
		
	}

}
