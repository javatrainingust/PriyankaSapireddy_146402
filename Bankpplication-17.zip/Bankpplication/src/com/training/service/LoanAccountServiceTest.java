package com.training.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.training.model.FdAccount;
import com.training.model.LoanAccount;

class LoanAccountServiceTest {
	
	LoanAccountService service = new LoanAccountService();
	LoanAccount account = new LoanAccount();

	@Test
	void testGetAllLoanAccountSortedByNames() {
		
		 String expectedValue = "Karthika";
			
			List<LoanAccount> loanAccount = service.getAllLoanAccountSortedByNames();
			
			String actualValue = loanAccount.get(0).getAccountHolderName();
			
			assertEquals(expectedValue, actualValue);
	}

	@Test
	void testGetAllLoanAccountSortedByLoanOutStandingAmount() {

		 String expectedValue ="Priyanka";
			
			List<LoanAccount> loanAccount = service.getAllLoanAccountSortedByLoanOutStandingAmount();
			
			String actualValue = loanAccount.get(0).getAccountHolderName();
			
			assertEquals(expectedValue, actualValue);
		
	}

}
