package com.training.service;

import java.util.Comparator;

import com.training.model.CurrentAccount;

public class CurrentaccountOverDraftLimitComparator implements Comparator<CurrentAccount> {

	@Override
	public int compare(CurrentAccount o1, CurrentAccount o2) {
		// TODO Auto-generated method stub
		return  (int) (o1.getOverDraftLimit()-o2.getOverDraftLimit());
	}

}
