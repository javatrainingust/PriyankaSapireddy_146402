package com.training.service;

public class LoanAccountSort {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LoanAccountService service =  new LoanAccountService();
		System.out.println("printing all  accounts");
		
		service.getAllLoanAccountdetails();
		System.out.println("----------------------");
		System.out.println();
		System.out.println("Print accounts after sorting");
		service.getAllLoanAccountSortedByNames();
		System.out.println("----------------------");
		System.out.println();
		System.out.println("Print accounts after sorting based on  LoanOutStandingAmount");
		service.getAllLoanAccountSortedByLoanOutStandingAmount();
		

	}

}
