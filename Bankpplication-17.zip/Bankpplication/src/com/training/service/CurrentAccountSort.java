package com.training.service;

public class CurrentAccountSort {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		CurrentAccountService service =  new CurrentAccountService();
		System.out.println("printing all  accounts");
		
		service.getAllCurrentAccounttdetails();
		System.out.println("----------------------");
		System.out.println();
		System.out.println("Print accounts after sorting");
		service.getAllCurrentAccountSortedByNames();
		System.out.println("----------------------");
		System.out.println();
		System.out.println("Print accounts after sorting based on  OverDraftlimit");
		service.getAllCurrentAccountSortedByOverDraftLimit();
		

	}

}
