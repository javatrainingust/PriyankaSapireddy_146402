package com.training.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.training.model.CurrentAccount;
import com.training.model.FdAccount;

class FdAccountServiceTest {
	
	FdAccountService service = new FdAccountService();
	FdAccount fd = new FdAccount();

	@Test
	void testGetAllFdAccountsSortedByNames() {
		
       String expectedValue = "Karthika";
		
		List<FdAccount> fdAccount = service.getAllFdAccountsSortedByNames();
		
		String actualValue = fdAccount.get(0).getAccountHolderName();
		
		assertEquals(expectedValue, actualValue);
		
	}

	@Test
	void testGetAllFdAccountsSortedByBalance() {
        String expectedValue = "Priyanka";
		
		List<FdAccount> fdAccount = service.getAllFdAccountsSortedByBalance();
		
		String actualValue = fdAccount.get(0).getAccountHolderName();
		
		assertEquals(expectedValue, actualValue);
		
		
	}

}
