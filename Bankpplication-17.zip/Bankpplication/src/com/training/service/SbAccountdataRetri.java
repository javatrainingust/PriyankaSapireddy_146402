/**
 * ClassName:SbAccountdataRetri
 * 
 * Description:MainMethod  for accessing process 
 * 
 * Date-06-10-2020
 * */





package com.training.service;

public class SbAccountdataRetri {
	
public static void main(String arg[]){
		
		SbAccountService service = new SbAccountService();
		
		      //retrieving all  accounts 
		
			    service.getAllSbAccountdetails() ;
				
				System.out.println("----------------------------------");
				
				
				service.getSbAccountByAccountNumber(1234);
				
				System.out.println("----------------------------------");
				System.out.println("after deleting one account");
				System.out.println("----------------------------------");
				
				service.deleteLoanAccount(1235);
				service.getAllSbAccountdetails();
				
		
				
	
	}

}
