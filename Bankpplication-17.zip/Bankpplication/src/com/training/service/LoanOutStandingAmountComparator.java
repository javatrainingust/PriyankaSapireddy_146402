package com.training.service;

import java.util.Comparator;

import com.training.model.LoanAccount;

public class LoanOutStandingAmountComparator  implements Comparator<LoanAccount>{

	@Override
	public int compare(LoanAccount o1, LoanAccount o2) {
		// TODO Auto-generated method stub
		return  (int) (o1.getLoanOutstanding()-o2.getLoanOutstanding());
	}

}
