package com.training.service;

public class SbAccountSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SbAccountService service =  new SbAccountService();
		System.out.println("printing all  accounts");
		
		service.getAllSbAccountdetails();
		System.out.println("----------------------");
		System.out.println();
		System.out.println("Print accounts after sorting");
		service.getAllSbAccountSortedByNames();
		System.out.println("----------------------");
		System.out.println();
		System.out.println("Print accounts after sorting based on  balance");
		service.getAllSbAccountSortedByBalance();
		

	}

}
