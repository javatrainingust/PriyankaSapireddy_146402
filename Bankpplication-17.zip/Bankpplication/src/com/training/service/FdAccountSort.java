package com.training.service;

public class FdAccountSort {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		FdAccountService service =  new FdAccountService();
		System.out.println("printing all  accounts");
		
		service.getAllFdaAccountdetails();
		System.out.println("----------------------");
		System.out.println();
		System.out.println("Print accounts after sorting");
		service.getAllFdAccountsSortedByNames();
		System.out.println("----------------------");
		System.out.println();
		System.out.println("Print accounts after sorting based on  balance");
		service.getAllFdAccountsSortedByBalance();
		

	}

}
