/**
 * ClassNAme: SbAccountServiceTest
 * 
 * Description: Testing pupose
 * 
 * Date: 08-10-2020
 */


package com.training.service;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;

import com.training.model.FdAccount;
import com.training.model.SbAccount;

/**
 * Testing 2 methods in Implementation class
 * 
 * GetAllSbAccountSortedByNames
 * 
 * GetAllSbAccountSortedByBalance
 * 
 * AddCurrent Account
 * 
 * UpdateCurrentAccount
 */
class SbAccountServiceTest {
	
	SbAccountService service = new SbAccountService();
	SbAccount account = new SbAccount();
	
/**
 *   GetAllSbAccountSortedByNames
 */
	@Test
	void testGetAllSbAccountSortedByNames() {
		 String expectedValue = "Karthika";
			
			List<SbAccount> sbAccount = service.getAllSbAccountSortedByNames();
			
			String actualValue = sbAccount.get(0).getAccountHolderName();
			
			assertEquals(expectedValue, actualValue);
	}

	/**
	 * testGetAllSbAccountSortedByBalance
	 */
	@Test
	void testGetAllSbAccountSortedByBalance() {
		 String expectedValue = "Priyanka";
			
			List<SbAccount> sbAccount = service.getAllSbAccountSortedByBalance();
			
			String actualValue = sbAccount.get(0).getAccountHolderName();
			
			assertEquals(expectedValue, actualValue);
	}
	
	/**
	 * testAddSbAccount
	 */
	@Test
	
	void testAddSbAccount() {
		
		int expectedSize = 2;
		
		service.addSbAccount(new SbAccount(1234, "Priyanka", 10000, 1.2f, 30));
		service.addSbAccount(new SbAccount(1235, "Sujatha", 90000, 1.3f, 40));
		List<SbAccount> actual = service.getAllSbAccountdetails();
		assertEquals(expectedSize, actual.size());
		
	}
     
     /**
      * testUpdateFdAccount
      */
     @Test
 	
 	void testUpdateFdAccount() {
 		
 		String  expectedValue = "Sujatha";
 		
 		service.updateSbAccount(new SbAccount(1235, "Sujatha", 100000, 1.3f, 40));
 		 
 		account = service. getSbAccountByAccountNumber(1235);
 		
 		String actualValue = account.getAccountHolderName();
 		
 		assertEquals(expectedValue, actualValue);
    	 
    	
    	 
    
 		
 		
 	}

}
