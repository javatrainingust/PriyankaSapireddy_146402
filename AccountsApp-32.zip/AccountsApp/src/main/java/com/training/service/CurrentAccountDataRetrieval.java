/**
 * ClassName:CurrentAccountDataRetrival
 * 
 * Description:MainMethod  for accessing process 
 * 
 * Date-06-10-2020
 * */



package com.training.service;
/**
 * Class  CurrentAccountDataRetrival  for accessing the outputs
 * 
 */
public class CurrentAccountDataRetrieval {
	
	/**
	 * Class  CurrentAccountDataRetrival  main method
	 * 
	 */	
public static void main(String arg[]){
		
	CurrentAccountService service = new CurrentAccountService();
		
		      //retrieving all  accounts 
		
			    service.getAllCurrentAccounttdetails();
				
				System.out.println("----------------------------------");
				
				
				service.getCurrentAccountByAccountNumber(1234);
				
				System.out.println("----------------------------------");
				System.out.println("after deleting one account");
				System.out.println("----------------------------------");
				
				service.deleteFdAccount(1235);
				service.getAllCurrentAccounttdetails();
				
		
				
	
	}

}
