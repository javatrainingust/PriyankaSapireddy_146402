package com.training.model;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

class CurrentAccountTest {

	@Test
	void testIsLimitExceed() {
		boolean expected = true;
		
		CurrentAccount ca = new CurrentAccount();
		
		ca.setOverDraftLimit(200000);
		
		boolean actual = ca.isLimitExceed(200000);
		
		assertEquals(expected,actual);
		
	}

}
