/*
 * Classname: FdAccount
 * 
 * Description: sub class that extends Account 
 * 
 * Date: 30/09/2020
 * 
 * 
 */

package com.training.model;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;


import com.training.util.Icalculator;
import com.training.util.InterestCalculator;


public class FdAccount extends Account implements Renewable,Comparable<FdAccount>{
	
	private int tenure ;
	
	private boolean autoRenewal;
	
	private float rate;
	
	/* creating non-parameterized and parameterized constructors*/
	

	public FdAccount(int accountNo,String accountHolderName,float balanceAmount,int tenure,float rate) {
		super(accountNo,accountHolderName,balanceAmount);
		
		 this.tenure =tenure;
		 this.rate = rate;
	}
	
	public FdAccount() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "FDAccount [tenure=" + tenure + " rate= " + rate +  "]";
	}
	
	
	
	public float getRate() {
		return rate;
	}
	
	public void setRate(float rate) {
		this.rate = rate;
	}
	
	
	public int getTenure() {
		return tenure;
	}
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	public boolean isAutoRenewal() {
		return autoRenewal;
	}
	public void setAutoRenewal(boolean autoRenewal) {
		this.autoRenewal = autoRenewal;
	}

	private Calendar maturity_date = Calendar.getInstance();
	
    public void calculateInterest(Icalculator calculator) {
    	
    	
    	/* Icalculator is an interface that implemented by InterestCalculator that calculate interest */
		
		float interesrt = calculator.calculateInterest(this.getBalanceAmount() ,this.rate);
		
		System.out.println("your FDAccount will have RS "+interesrt+ " as interest  with rate "+this.rate);
		
	}



	public Calendar autoRenewable(int ternure) {
		
		System.out.println("insude auto renewable");
		
		 Date todate = new Date();
		 
	     this.autoRenewal=true;
	     
	     Calendar mycal=new GregorianCalendar(2020,9,20);
	     
	     Date MaturityDate=mycal.getTime();

	     
	 	if(autoRenewal==true)
	 	{
	 		if(MaturityDate.compareTo(todate)<0 |MaturityDate.equals(todate))
	 		{
	 			Calendar calendar= Calendar.getInstance();
	 			
	 			
	 			calendar.add(Calendar.MONTH, tenure);
	 		    System.out.println("Date" +calendar.getTime());
	 		    
	 		}
	 		
		
		 }
		return maturity_date;
	

	}

	
	public int compareTo(FdAccount o) {
		// TODO Auto-generated method stub
		return this.accountHolderName.compareTo(o.getAccountHolderName());
	}
}
