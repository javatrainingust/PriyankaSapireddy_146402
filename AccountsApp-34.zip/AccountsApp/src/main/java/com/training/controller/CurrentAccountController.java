/**
 * Class Name: SbAccountController
 * 
 * Description: Class which is used give the http request to server by using @Controller and @RequestMapping
 * 
 * Date:15/10/2020
 */
package com.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.model.CurrentAccount;
import com.training.model.FdAccount;
import com.training.model.SbAccount;
import com.training.service.CurrentAccountService;
import com.training.service.FdAccountService;
/**
 *  Class which is used give the http request to server by using @Controller and @RequestMapping
 * 
 * @author sanga
 *
 */
@Controller
public class CurrentAccountController {

	@Autowired
	private CurrentAccountService service;
	
	/**
	 * getAllCurrentAccounts method to get all Accounts 
	 * @param model
	 * @return
	 */
	@RequestMapping("/caccounts")
	
	public String getAllCurrentAccounts(Model model){
		
		System.out.println("Inside controller getAllCurrentAccounts ");
		
		List<CurrentAccount> employeeList = service.getAllCurrentAccounttdetails();
		
		model.addAttribute("caccounts",employeeList );
		
		
		return "currentAccountList";
		

}
	/**
	 * showFdAccountForm  method to show FdAccount Form 
	 * @param model
	 * @return
	 */
	@RequestMapping("/showCurrentAccountform")
	public String  showFdAccountForm(Model model){
		
		CurrentAccount pe = new CurrentAccount();
		
	   model.addAttribute("key",pe );
		
		
		return "addCurrentAccount";
		

}
	/**
	 * addEmployee  method to addCurrentAccount
	 * @param pe 
	 * @return redirect:/caccounts
	 */

	@RequestMapping("/addCurrentAccount")
	public String addEmployee(@ModelAttribute("fdAccount") CurrentAccount pe) {
		
		
		service.addCurrentAccount(pe);
		
		return "redirect:/caccounts";
		
		
	}
	/**
	 * getaccount method to getCurrentAccountByAccountNumber
	 * @param accountNo
	 * @param model
	 * @return viewcurrentAccount
	 */
	@RequestMapping("/viewcurrentAccount")
	public String getaccount(@RequestParam("accountNo")String accountNo,Model model) {
		
		
		CurrentAccount pe = service.getCurrentAccountByAccountNumber(Integer.parseInt(accountNo));
		
		model.addAttribute("key", pe);
		
		
		return "viewcurrentAccount";
		
		
	}
	/**
	 * deletecurrentAccount method to deleteCurrentAccount
	 * @param accountNo
	 * @param model
	 * @return "redirect:/caccounts"
	 */
	@RequestMapping("/deletecuAccount")
	public String deletecurrentAccount(@RequestParam("accountNo")String accountNo,Model model) {
	
		
     service.deleteCurrentAccount(Integer.parseInt(accountNo));
		
		
		
		
    return  "redirect:/caccounts";
		
		
	}
}
