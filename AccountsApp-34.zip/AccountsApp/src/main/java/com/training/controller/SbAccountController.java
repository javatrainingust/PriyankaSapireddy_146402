/**
 * Class Name: SbAccountController
 * 
 * Description: Class which is used give the http request to server by using @Controller and @RequestMapping
 * 
 * Date:15/10/2020
 */

package com.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.model.CurrentAccount;
import com.training.model.FdAccount;
import com.training.model.SbAccount;
import com.training.service.CurrentAccountService;
 import com.training.service.SbAccountService;
/**
 *  Class which is used give the http request to server by using @Controller and @RequestMapping
 * @author sanga
 *
 */
 @Controller
public class SbAccountController {
	
	@Autowired
	private SbAccountService service;
	
	/**
	 *  getAllSbAccounts method to get all sb accounts  
	 *  
	 */
	@RequestMapping("/sbaccounts")
	public String getAllSbAccounts(Model model){
		
		System.out.println("Inside controller getAlSBAccounts ");
		
		List<SbAccount> employeeList = service.getAllSbAccountdetails();
		
		model.addAttribute("sbaccounts",employeeList );
		
		
		return "sbAccountList";
		
	}
	/**
	 *  showSBAccountForm  method to show showSBAccountForm
	 * @param model
	 * @return addSbAccount
	 */
	@RequestMapping("/showSbAccountform")
	public String  showSBAccountForm(Model model){
		
		SbAccount pe = new SbAccount();
		
	   model.addAttribute("key",pe );
		
		
		return "addSbAccount";
		

}
    /**
     * addSbAccount method to addSbAccount
     * @param pe
     * @return "redirect:/sbaccounts"
     */
	@RequestMapping("/addSbAccount")
	public String addSbAccount(@ModelAttribute("fdAccount") SbAccount pe) {
		
		
		service.addSbAccount(pe);
		
		return "redirect:/sbaccounts";
		
		
	}
	/**
	 * getSbAccountByAccountNumber method  to getSbAccountByAccountNumber
	 * @param accountNo
	 * @param model
	 * @return viewSbAccount.jsp file
	 */
	@RequestMapping("/viewSbAccount")
	public String getSbAccountByAccountNumber(@RequestParam("accountNo")String accountNo,Model model) {
		
		
		SbAccount pe = service.getSbAccountByAccountNumber(Integer.parseInt(accountNo));
		
		model.addAttribute("key", pe);
		
		
		return "viewSbAccount";
		
		
	}
	/**
	 * deleteSbaccount  method is to deleteSbaccount
	 * @param accountNo
	 * @param model
	 * @return "redirect:/sbaccounts"
	 */
	@RequestMapping("/deletesbAccount")
	public String deleteSbaccount(@RequestParam("accountNo")String accountNo,Model model) {
		
		
		 service.deleteLoanAccount(Integer.parseInt(accountNo));
		
		
		
		
		return "redirect:/sbaccounts";
		
		
	}
}
