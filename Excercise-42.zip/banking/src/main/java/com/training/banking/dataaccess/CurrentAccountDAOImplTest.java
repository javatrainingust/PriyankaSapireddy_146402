/**
 * ClassName:CurrentAccountDAOImplTest
 * 
 * Description:JuintTesting
 * 
 * Date-06-10-2020
 * */




package com.training.banking.dataaccess;



import static org.junit.Assert.assertEquals;
import org.junit.Test;

import com.training.banking.model.CurrentAccount;

import java.util.List;
/**
 * CurrentAccountDAOImplTest for testing implementation class methods
 * @author sanga
 *
 */
class CurrentAccountDAOImplTest {

	CurrentAccountDAO dao = new CurrentAccountDAOImpl();
	CurrentAccount ca = new CurrentAccount();

	@Test
	void testGetAllCurrentAccounttdetails() {

		int expected = 3;
		List<CurrentAccount> actual = dao.getAllCurrentAccounttdetails();
		assertEquals(expected, actual.size());

	}

	@Test
	void testGetCurrentAccountByAccountNumber() {

		String expectedValue = "Priyanka";

		ca = dao.getCurrentAccountByAccountNumber(1234);

		String actualValue = ca.getAccountHolderName();

		assertEquals(expectedValue, actualValue);

	}

	@Test
	void testDeleteCurrentAccount() {

		int expectedSize = 2;
		dao.deleteCurrentAccount(1235);
		List<CurrentAccount> actual = dao.getAllCurrentAccounttdetails();
		assertEquals(expectedSize, actual.size());
	}
	
	

	
	
	
		
	}

	

