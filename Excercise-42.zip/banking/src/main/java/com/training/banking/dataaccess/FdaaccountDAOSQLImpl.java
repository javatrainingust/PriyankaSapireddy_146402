/**
 * Class : FdaaccountDAOSQLImpl 
 * Description : FdaaccountDAOSQLImpl  class  that implements  FdaaccountDao interface  serves as Repository
 * Date: 23/10/2020
 */
package com.training.banking.dataaccess;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.training.banking.model.FdAccount;
/**
 *  FdaaccountDAOSQLImpl  class  that implements  FdaaccountDao interface  serves as Repository
 * @author sanga
 *
 */


@Repository
public class FdaaccountDAOSQLImpl implements FdaaccountDao {

	private DataSource dataSource;

	private JdbcTemplate jdbcTemplateObject;
		
		@Autowired
		public void setDataSource(DataSource dataSource) {
			this.dataSource = dataSource;
			jdbcTemplateObject = new JdbcTemplate(dataSource);
		}
		
		/**
		 * getAllFdaAccountdetails method to get all accounts 
		 */
	public List<FdAccount> getAllFdaAccountdetails() {
		
		String SQL = "SELECT * FROM banking.fdaccount";
		
	      List <FdAccount> employees= jdbcTemplateObject.query(SQL, new FdAccountMapper());
		
		return employees;
	}
/**
 * getFdAccountByAccountNumber method to get all accounts by using account Number
 */
	public FdAccount getFdAccountByAccountNumber(int accountNo) {
		String sql = "select * from banking.fdaccount where accountNo= ?";
		 
		FdAccount employee = (FdAccount) jdbcTemplateObject.queryForObject(
                sql, new Object[] { accountNo }, new FdAccountMapper());
      
       return 	employee;	
	}

	/**
	 * deleteFdAccount is used to  delete account by using account number
	 */
	public void deleteFdAccount(int accountNo) {
		 String query="delete from banking.fdaccount where accountNo ='"+accountNo+"' ";  
		 jdbcTemplateObject.update(query);  

	}	
/**
 * addFdAccount is used add a new account 
 */
	public boolean addFdAccount(FdAccount fdAccount) {
		String sql = "Insert into  banking.fdaccount" +
				 "(accountNo,accountHolderName,balanceAmount,rate,tenure) values(?,?,?,?,?)";
				

			  jdbcTemplateObject.update(sql, new Object[] { fdAccount.getAccountNo(),
					  fdAccount.getAccountHolderName(), fdAccount.getBalanceAmount(),
					  fdAccount.getRate(),fdAccount.getTenure()
			        });
				return true;
	}
/**
 * updatefdAccount  to make changes in the account details 
 */
	public void updateFdAccount(FdAccount fdAccount) {
		String query="update banking.loanaccount set accountNo'"+ fdAccount.getAccountNo()+"',"
				+ " accountHolderName ='"+fdAccount.getAccountHolderName()+"' where accountNo ='"+fdAccount.getAccountNo()+"' ";  
	    jdbcTemplateObject.update(query); 

	}

}
