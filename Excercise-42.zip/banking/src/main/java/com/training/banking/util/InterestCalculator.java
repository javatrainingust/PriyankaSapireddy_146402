/*
 * Classname: Interestcalculator
 * 
 * Description: a class that implements Icalculator 
 * 
 * Date: 30/09/2020
 * 
 * 
 */

package com.training.banking.util;

public class InterestCalculator implements Icalculator {
	
	private float principle = 50000f ;
	
	private float timePeriod= 5f ;
	
	
	//overloading methods of  calculateInterest
	
	public float calculateInterest(float rateOfInterest) {
		
		float si = (principle*timePeriod*rateOfInterest)/100 ;
		
		System.out.println("Simple Interest is=   "+si);
		
		return si;
	}
	

	public Float calculateInterest(float principle,float rate) {
		
		int time =1;
		
		float intrest = (principle*time*rate)/100; 
		
		System.out.println("Simple Interest is=   "+intrest );
		
		return intrest;
		
	}
		

}
