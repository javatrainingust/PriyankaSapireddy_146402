/**
 * Class Name: SbAccountController
 * 
 * Description: Class which is used give the http request to server by using @Controller and @RequestMapping
 * 
 * Date:15/10/2020
 */

package com.training.banking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.training.banking.model.CurrentAccount;
import com.training.banking.model.FdAccount;
import com.training.banking.model.SbAccount;
import com.training.banking.service.CurrentAccountService;
import com.training.banking.service.SbAccountService;

/**
 * Class which is used give the http request to server by using @Controller
 * and @RequestMapping
 * 
 * @author sanga
 *
 */
@RestController
public class SbAccountController {

	@Autowired
	private SbAccountService service;

	/**
	 * getAllSbAccounts method to get all sb accounts
	 * 
	 */
	@GetMapping("/sbaccounts") 
	public List<SbAccount> getAllSbAccounts() {

		List<SbAccount> employeeList = service.getAllSbAccountdetails();

		return employeeList;

	}
	@GetMapping("/sbaccounts-balance/{balanceAmount}") 
	public List<SbAccount> getSbAccountBasedOnBalance(@PathVariable float balanceAmount){
		
		
		List<SbAccount> employeeList = service.getSbAccountBasedOnBalance(balanceAmount);
		
				
		return employeeList;
		
	}

	

	/**
	 * addSbAccount method to addSbAccount
	 * 
	 * @param pe
	 * @return "redirect:/sbaccounts"
	 */
	@PostMapping("/sbaccounts") 
	public SbAccount addSbAccount(@RequestBody SbAccount pe) {

		service.addSbAccount(pe);

		return  pe;

	}
	/**
	 * updateSbAccount method to updateSbAccount
	 * @param pe
	 * @return
	 */
	@PutMapping("/sbaccounts/{accountNo}")
	public SbAccount updateSbAccount( @PathVariable  int  accountNo,@RequestBody SbAccount pe) {

		service.updateSbAccount(pe);

		return pe;

	}


	/**
	 * getSbAccountByAccountNumber method to getSbAccountByAccountNumber
	 * 
	 * @param accountNo
	 * @param model
	 * @return viewSbAccount.jsp file
	 */
	@GetMapping("/sbaccounts/{accountNo}") 
	public SbAccount getSbAccountByAccountNumber(@PathVariable int accountNo) {

		SbAccount pe = service.getSbAccountByAccountNumber(accountNo);

		return pe;

	}
	@RequestMapping("/sortsbAccounyByName")
	public String getAllSbAccountsByName(Model model) {

		System.out.println("Inside controller getAlSBAccounts ");

		List<SbAccount> employeeList = service.getAllSbAccountSortedByNames();

		model.addAttribute("sbaccounts", employeeList);

		return "sbAccountList";

	}
	@RequestMapping("/sortsbAccounyByBalance")
	public String getAllSbAccountsByBalance(Model model) {

		System.out.println("Inside controller getAlSBAccounts ");

		List<SbAccount> employeeList = service.getAllSbAccountSortedByBalance();

		model.addAttribute("sbaccounts", employeeList);

		return "sbAccountList";

	}

	/**
	 * deleteSbaccount method is to deleteSbaccount
	 * 
	 * @param accountNo
	 * @param model
	 * @return "redirect:/sbaccounts"
	 */
	@DeleteMapping("/sbaccounts/{accountNo}") 
	public void deleteSbaccount( @PathVariable  int  accountNo) {

		service.deleteLoanAccount(accountNo);

	

	}
}
