package com.training.banking.services;

import com.training.banking.model.FdAccount;
import com.training.banking.model.Renewable;

public class AutomaticRenewableService {
	
	public static void main(String[] args) {
	
	Renewable r = new FdAccount();
	r.autoRenewable(6);
	}

}
