package com.training.banking.model;





import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.training.banking.Exception.InsufficiantMoneyException;

class AccountTest {

	@Test
	void testWithDrawAmount() {
		int expected = 8000;
		Account a = new Account();
		try {
			a.withDrawAmount(2000);
		} catch (InsufficiantMoneyException e) {
		
			e.printStackTrace();
		}
		float actual = a.getBalanceAmount();
		assertEquals(expected,actual);
		
		
		
	}

}
