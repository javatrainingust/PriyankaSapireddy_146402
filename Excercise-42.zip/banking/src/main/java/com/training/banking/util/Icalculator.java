/*
 * Interfacename: Icalculator
 * 
 * Description: interface that has been implemented by  InterestCalculator class
 * 
 * Date: 30/09/2020
 * 
 * 
 */



package com.training.banking.util;

public interface Icalculator {
	
	public float calculateInterest(float rateOfInterest);
	
	public Float calculateInterest(float principle,float rate);

}
