/**
 * Class: LoanAccountMapper
 * Description: LoanAccountMapper class that implements RowMapper 
 * Date:23/10/2020
 */
package com.training.banking.dataaccess;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.training.banking.model.LoanAccount;
import com.training.banking.model.SbAccount;
/**
 * LoanAccountMapper class that implements RowMapper 
 * @author sanga
 *
 */
public class LoanAccountMapper  implements RowMapper<LoanAccount>{

	public LoanAccount mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		LoanAccount  pe = new LoanAccount();
		/**
		 * setting values by ResultSet reference variable
		 */
		pe.setAccountNo(rs.getInt("accountNo"));
		pe.setAccountHolderName(rs.getString("accountHolderName"));
	    pe.setBalanceAmount(rs.getFloat("balanceAmount"));
	    pe.setEmi(rs.getFloat("emi"));
	    pe.setLoanOutstanding(rs.getFloat("loanOutstanding"));
	    pe.setTernure(rs.getInt(rs.getInt("ternure")));
		
		return pe;
	}

}

