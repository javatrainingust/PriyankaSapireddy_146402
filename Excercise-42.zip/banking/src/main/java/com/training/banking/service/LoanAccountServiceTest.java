/**
 * ClassNAme: LoanAccountTest
 * 
 * Description: Test for LoanAccountDaoImplementation
 * 
 * Date-08-10-2020
 */


package com.training.banking.service;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;

import com.training.banking.model.FdAccount;
import com.training.banking.model.LoanAccount;

/**
 * Testing 2 methods in Implementation class
 * 
 * 1.AddCurrent Account
 * 
 * 2.UpdateCurrentAccount
 */
class LoanAccountServiceTest {
	
	LoanAccountService service = new LoanAccountService();
	LoanAccount account = new LoanAccount();

//	@Test
//	void testGetAllLoanAccountSortedByNames() {
//		
//		 String expectedValue = "Karthika";
//			
//			List<LoanAccount> loanAccount = service.getAllLoanAccountSortedByNames();
//			
//			String actualValue = loanAccount.get(0).getAccountHolderName();
//			
//			assertEquals(expectedValue, actualValue);
//	}
//
//	@Test
//	void testGetAllLoanAccountSortedByLoanOutStandingAmount() {
//
//		 String expectedValue ="Priyanka";
//			
//			List<LoanAccount> loanAccount = service.getAllLoanAccountSortedByLoanOutStandingAmount();
//			
//			String actualValue = loanAccount.get(0).getAccountHolderName();
//			
//			assertEquals(expectedValue, actualValue);
//		
//	}
	
	 @Test
		
		void testAddLoanAccount() {
		 
			int expectedSize = 2;
			service.addLoanAccount(new LoanAccount(1234,"Priyanka",10000,1.2f,10000,3));
			service.addLoanAccount(new LoanAccount(1235,"Sujatha",90000,1.4f,10000,2));
			List<LoanAccount> actual = service.getAllLoanAccountdetails();
			assertEquals(expectedSize, actual.size());
			
		}
	 
	 @Test
	 	
	 	void testUpdateLoanAccount() {
	 		
	 		String  expectedValue = "Sujatha";
	 		
	 		service.updateLoanAccount(new LoanAccount(1235,"Sujatha",90000,1.4f,10000,2));
	 		 
	 		account = service. getLoanAccountByAccountNumber(1235);
	 		
	 		
	 		String actualValue = account.getAccountHolderName();
	 		
	 		assertEquals(expectedValue, actualValue);
	    	 
	    	
	    	 
	    
	 		
	 		
	 	}
	
	
	

}
