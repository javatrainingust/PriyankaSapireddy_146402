/**
 * ClassName:  LoanAccountSort
 * 
 * Description:MainMethod  for accessing process 
 * 
 * Date-06-10-2020
 * */

package com.training.banking.service;

/**
 * class with MainMethod  for accessing process 
 * @author sanga
 *
 */
public class LoanAccountSort {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LoanAccountService service =  new LoanAccountService();
		System.out.println("printing all  accounts");
		
		service.getAllLoanAccountdetails();
		System.out.println("----------------------");
		System.out.println();
		System.out.println("Print accounts after sorting by names");
		service.getAllLoanAccountSortedByNames();
		System.out.println("----------------------");
		System.out.println();
		System.out.println("Print accounts after sorting based on  LoanOutStandingAmount");
		service.getAllLoanAccountSortedByLoanOutStandingAmount();
		

	}

}
