/**
 * Class: SbaccountMapper
 * Description: SbaccountMapper class that implements RowMapper 
 * Date:23/10/2020
 */
package com.training.banking.dataaccess;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.training.banking.model.SbAccount;
/**
 * SbaccountMapper class that implements RowMapper 
 * @author sanga
 *
 */
public class SbaccountMapper  implements RowMapper<SbAccount>{

	public SbAccount mapRow(ResultSet rs, int rowNum) throws SQLException {
		/**
		 * setting values by ResultSet reference variable
		 */
		SbAccount pe = new SbAccount();
		pe.setAccountNo(rs.getInt("accountNo"));
        pe.setAccountHolderName(rs.getString("accountHolderName"));
        pe.setBalanceAmount(rs.getFloat("balanceAmount"));
        pe.setRate(rs.getFloat("rate"));
        pe.setTime(rs.getInt("time"));
		return pe;
	}

}
