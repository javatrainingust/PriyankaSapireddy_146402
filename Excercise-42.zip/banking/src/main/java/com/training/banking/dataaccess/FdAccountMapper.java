/**
 * Class: FdAccountMapper
 * Description: FdAccountMapper class that implements RowMapper 
 * Date:23/10/2020
 */
package com.training.banking.dataaccess;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.training.banking.model.FdAccount;

/**
 * 
 * FdAccountMapper class that implements RowMapper 
 *
*/
public class FdAccountMapper  implements RowMapper<FdAccount>{

	public FdAccount mapRow(ResultSet rs, int rowNum) throws SQLException {
		/**
		 * setting values by ResultSet reference variable
		 */
		FdAccount pe = new FdAccount();
		pe.setAccountNo(rs.getInt("accountNo"));
        pe.setAccountHolderName(rs.getString("accountHolderName"));
        pe.setBalanceAmount(rs.getFloat("balanceAmount"));
        pe.setRate(rs.getFloat("rate"));
        pe.setTenure(rs.getInt("tenure"));
		return pe;
	}

}
