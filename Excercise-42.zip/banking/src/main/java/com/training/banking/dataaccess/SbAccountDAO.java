/**
 * InterfaceName: SbAccountDao
 * 
 * Description:Interface for adding,retrieving,deleting details in currentAccount
 * 
 * Date -06-10-2020
 */




package com.training.banking.dataaccess;

import java.util.List;

import com.training.banking.model.FdAccount;
import com.training.banking.model.LoanAccount;
import com.training.banking.model.SbAccount;

public interface SbAccountDAO {
	
	
	public List<SbAccount > getAllSbAccountdetails();
	 
	public SbAccount  getSbAccountByAccountNumber(int accountNo);
	
	public void deleteSbAccount(int accountNo);
	
	 public boolean addSbAccount(SbAccount sbAccount);
	    
	  public void updateSbAccount(SbAccount sbAccount);


}
