/**
 * Class Name: FdAccountController
 * 
 * Description: Class which is used give the http request to server by using @Controller and @RequestMapping
 * 
 * Date:15/10/2020
 */
package com.training.banking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.training.banking.model.FdAccount;
import com.training.banking.model.SbAccount;
import com.training.banking.service.FdAccountService;


/**
 * FdAccountController Class which is used give the http request to server by using @Controller and @RequestMapping
 * @author sanga
 *
 */
@RestController
public class FdAccountController {
	
	@Autowired
	private FdAccountService service;
	
	/**
	 * getAllAccounts method to get all FD Accounts
	 * @return to fdAccountList
	 */
	
	@GetMapping("/fdaccounts") 
	public List<FdAccount> getAllfdAccounts(){
		
		List<FdAccount> employeeList = service.getAllFdaAccountdetails();
		
		return employeeList;
		}
	/**
	 * getFdAccountBasedOnBalance used to get account based on given balance amount 
	 * @param basic
	 * @return
	 */
	@GetMapping("/fdaccounts-balance/{balanceAmount}") 
	public List<FdAccount> getFdAccountBasedOnBalance(@PathVariable float balanceAmount){
		
		
		List<FdAccount> employeeList = service.getFdAccountBasedOnBalance(balanceAmount);
		
				
		return employeeList;
		
	}

	/**
	 * addEmployee  method to addFdAccount
	 * @param pe
	 * @return FdAccount
	 */
	@PostMapping("/fdaccounts") 
	public FdAccount  addEmployee(@RequestBody FdAccount pe) {
		
		
		service.addFdAccount(pe);
		
		return pe;
		
		
	}
	/**
	 * updatefdAccount  method to updatefdAccount
	 * @param pe
	 * @return pe
	 */
	@PutMapping(value="/fdaccounts/{accountNo}")
	public FdAccount updatefdAccount(@RequestBody FdAccount pe) {
		
		
		service.updateFdAccount(pe);
		
		return pe;
		
		
	}
	
	/**
	 * getaccount method to getFdAccount By AccountNumber 
	 * @return to fdAccountList
	 */
	
	@GetMapping("/fdaccounts/{accountNo}") 
	public FdAccount getaccount(@PathVariable int accountNo) {
		
		
		FdAccount pe = service.getFdAccountByAccountNumber(accountNo);
		
		
		
		
		return pe;
		
		
	}
	/**
	 * updatefdAccountsbyName method can be used for getAllFdAccountsSortedByNames
	 * @param model
	 * @return fdAccountList
	 */
	@RequestMapping("/sortAccounyByName")
	public String  sortfdAccountsbyName(Model model){
		
		System.out.println("Inside controller getAllAccounts ");
		
		List<FdAccount> employeeList = service.getAllFdAccountsSortedByNames();
		
		model.addAttribute("fdaccounts",employeeList );
		
		
		return "fdAccountList";
		

}
	/**
	 * updatefdAccountsbyBalance  method can be used for getAllFdAccountsSortedByBalance
	 * @param model
	 * @return fdAccountList
	 */
	@RequestMapping("/sortAccounyByBalance")
	public String updatefdAccountsbyBalance(Model model){
		
		System.out.println("Inside controller getAllAccounts ");
		
		List<FdAccount> employeeList = service.getAllFdAccountsSortedByBalance();
		
		model.addAttribute("fdaccounts",employeeList );
		
		
		return "fdAccountList";
		

}
	
	/**
	 * deleteFdaccount method to  delete Fdaccount By AccountNumber 
	 * @return to fdAccountList
	 */
	@DeleteMapping(value="/fdaccounts/{accountNo}") 
	public void deleteFdaccount(@PathVariable int accountNo) {
		
		
	 service.deleteFdAccount(accountNo);
		
	
		
		
	
		
		
	}
}
