/**
 * InterfaceName: FdaaccountDao
 * 
 * Description:Interface for adding,retrieving,deleting details in currentAccount
 * 
 * Date -06-10-2020
 */


package com.training.banking.dataaccess;

import java.util.List;

import com.training.banking.model.FdAccount;
/**
 * Interface with abstract methods
 * @author sanga
 *
 */
public interface FdaaccountDao {
	
	public List<FdAccount> getAllFdaAccountdetails();
 
	public FdAccount  getFdAccountByAccountNumber(int accountNo);
	
	public void deleteFdAccount(int accountNo);
	
    public boolean addFdAccount(FdAccount fdAccount);
    
    public void updateFdAccount(FdAccount fdAccount);
    
	
	
}
