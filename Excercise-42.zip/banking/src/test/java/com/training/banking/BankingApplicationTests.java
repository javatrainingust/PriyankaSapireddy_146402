package com.training.banking;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.mockito.junit.MockitoJUnitRunner;

import com.training.banking.dataaccess.SbAccountDAO;
import com.training.banking.model.FdAccount;
import com.training.banking.model.SbAccount;
import com.training.banking.service.FdAccountService;
import com.training.banking.service.SbAccountService;



@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
class BankingApplicationTests {

	@Mock
	private SbAccountDAO SbaaccountDAOMock;
	
	@InjectMocks
   private SbAccountService service;

	
//	  @Test 
//	  public void getFdAccountBasedOnBalanceTest() {
//	  
//	  assertEquals(2, service.getSbAccountBasedOnBalance(10000).size());
//	  
//	  }
	 
	@Test 
	  public void testGetAllEmployeesBySalary() {
		
		SbAccount pe1 = new SbAccount();
		pe1.setBalanceAmount(50000);
		
		SbAccount pe2 = new SbAccount();
		pe2.setBalanceAmount(40000);
		
		SbAccount pe3 = new SbAccount();
		pe3.setBalanceAmount(80000);
		
		SbAccount pe4 = new SbAccount();
		pe4.setBalanceAmount(20000);
		
		SbAccount pe5 = new SbAccount();
		pe5.setBalanceAmount(10000);
		
		List<SbAccount> employees = new ArrayList();
		
		employees.add(pe1);
		employees.add(pe2);
		employees.add(pe3);
		employees.add(pe4);		
		employees.add(pe5);
		
		
		when(SbaaccountDAOMock.getAllSbAccountdetails()).thenReturn(employees);
		  
		  
		  
		  assertEquals(3,service.getSbAccountBasedOnBalance(20000).size());
		
	}



	

}
