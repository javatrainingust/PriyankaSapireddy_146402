/**
 * Class: Excercise_1
 * 
 *Description: class that create stream of numbers,double the value  and return the number greater than 10
 *
 *Date: 09/10/2020
 */
package com.ust.training.Streamexcercise;

import java.util.stream.Stream;
/**
 *  class that create stream of numbers,double the value  and return the number greater than 10 
 */
public class Excercise_1 {
	
	/**
	 * Main method
	 * 
	 */
	public static void main(String[] args) {
		
		Stream<Integer> myStream =Stream.of(1,2,3,4,5,6,7,8,9);
		
        long noOfElements = myStream.map((n)->(n*2)).filter((i)->i>10).count();
		
		
		System.out.println("Number of even numbers: "+noOfElements);

	}

}
