/**
 * Class: Excercise_2
 * 
 *Description: class that create stream of students using Strem.of() method and sort them
 *
 *Date: 09/10/2020
 */


package com.ust.training.Streamexcercise;

import java.util.stream.Stream;

/**
 * class that create stream of students using Strem.of() method and sort them
 * @author sanga
 *
 */
public class Excercise_2 {
/**
 * Main method
 *
 */
	public static void main(String[] args) {
		
		Stream<String> studentstream = Stream.of("Ravi","Krishna","Sudeeer").sorted();
		
		//forEach method uses consumer as argument. Consumer accepts input but does not return anything.
		studentstream.forEach((e)->System.out.println(e));
		
		
		
	}
	}
