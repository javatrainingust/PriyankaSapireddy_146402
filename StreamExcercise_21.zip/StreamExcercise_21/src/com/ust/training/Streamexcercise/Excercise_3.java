/**
 * Class: Excercise_3
 * 
 *Description: class that create stream of Cat  from Cat class sorted based on their AGE
 *
 *Date: 09/10/2020
 */



package com.ust.training.Streamexcercise;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
/**
 * class that create stream of Cat ARRAYlIST from Cat class sorted based on their AGE
 * @author sanga
 *
 */
public class Excercise_3 {
/**
 * MAIN METHOD
 * @param args
 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List cats = new ArrayList<Cat>();
		
		Cat cat1 = new Cat("rosy",2);

		Cat cat2 = new Cat("pinky",3);

		Cat cat3 = new Cat("rosy",2);
		
		cats.add(cat1);
		cats.add(cat2);
		cats.add(cat3);
		
      Stream<Cat> catStream = cats.stream();
		
		Stream<Cat> sortedCatStream = catStream.sorted();
		
		sortedCatStream.forEach((e)->System.out.println(e));
		
		

	}

}
