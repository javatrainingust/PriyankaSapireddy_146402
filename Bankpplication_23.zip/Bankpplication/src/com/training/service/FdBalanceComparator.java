/**
 * ClassName:  FdBalanceComparator
 * 
 * Description: class implements comparator for comparison process
 * 
 * Date-06-10-2020
 * */

package com.training.service;

import java.util.Comparator;

import com.training.model.FdAccount;
/**
 * class implements comparator for comparison process
 * @author sanga
 *
 */
public class FdBalanceComparator implements Comparator<FdAccount>  {

	@Override
	public int compare(FdAccount one, FdAccount two) {
		// TODO Auto-generated method stub
		return (int) (one.getBalanceAmount()-two.getBalanceAmount());
	}

}
