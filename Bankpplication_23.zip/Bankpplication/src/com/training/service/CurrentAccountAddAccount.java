/**
 * Name: CurrentAccountAddAccount
 * Description: This is  for adding and updating the  CurrentAccount.
 * Date: 06/10/2020
 */



package com.training.service;

import com.training.model.CurrentAccount;

import com.training.model.FdAccount;

/**CurrentAccountAddAccount class is for display outputs */
public class CurrentAccountAddAccount {
	
	/**
	 * main method 
	 * 
	 * */
	
	public static void main(String[] args) {
		
     CurrentAccountService service = new CurrentAccountService();
		
		service.addCurrentAccount(new CurrentAccount(1234, "Priyanka", 10000, 40000));
		service.addCurrentAccount(new CurrentAccount(1235, "Sujatha", 90000, 100000));
		service.addCurrentAccount(new CurrentAccount(1235, "Sujatha", 90000, 100000));
		
		System.out.println("Printing all Accounts");	
		service.getAllCurrentAccounttdetails();
		System.out.println("---------------------------------------------");	
		
        service.updateCurrentAccount(new CurrentAccount(1235, "Sujatha", 100000, 100000));
		
		System.out.println("Printing all updated Accounts");	
		
		service.getAllCurrentAccounttdetails();
		
	}

}
