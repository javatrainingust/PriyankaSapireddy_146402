/***
 * ClassNAme:SavingsBankDAOImpl
 * 
 * Description:Implementing SbAccountDAO
 * 
 * Date-06-10-2020
 */

package com.training.dataaccess;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.training.model.FdAccount;
import com.training.model.LoanAccount;
import com.training.model.SbAccount;

public class SbAccountDAOImpl implements SbAccountDAO {

	/* Adding to List invoking objects in constructors */

	List sbAccountList;
	Set  sbAccountSet;

	public SbAccountDAOImpl() {

		sbAccountList = new ArrayList<SbAccount>();
		
		sbAccountSet = new HashSet<SbAccount>();

		
		  SbAccount fdac1 = new SbAccount(1234, "Priyanka", 10000, 1.2f, 30); 
		  SbAccount fdac2 = new SbAccount(1235, "Sujatha", 90000, 1.4f, 40); 
		  SbAccount fdac3 = new SbAccount(1236, "Karthika", 130000, 1.3f, 50);
		  
		  sbAccountList.add(fdac1); 
		  sbAccountList.add(fdac2);
		  sbAccountList.add(fdac3);
		 

	}

	// get all the Accountdetails
	@Override
	public List<SbAccount> getAllSbAccountdetails() {
		// TODO Auto-generated method stub
		return sbAccountList;
	}

	// get Accountdetails based on AccountNumber
	@Override
	public SbAccount getSbAccountByAccountNumber(int accountNo) {

		SbAccount sbAccount = null;

		Iterator<SbAccount> iterator = sbAccountList.iterator();

		while (iterator.hasNext()) {

			SbAccount pe = iterator.next();

			if (pe.getAccountNo() == accountNo) {

				sbAccount = pe;
			}

		}

		return sbAccount;

	}

	// deleting the account based on accountNumber
	@Override
	public void deleteSbAccount(int accountNo) {

		SbAccount sbAccount = null;

		for (int i = 0; i < sbAccountList.size(); i++) {

			sbAccount = (SbAccount) sbAccountList.get(i);

			if (sbAccount.getAccountNo() == accountNo) {

				sbAccountList.remove(i);

			}

		}

	}

	@Override
	public boolean addSbAccount(SbAccount sbAccount) {
	
      boolean isAdded =  sbAccountSet.add(sbAccount);
		
		if(isAdded){
			sbAccountList.add(sbAccount);
			 
		}
		return isAdded;
	
	}

	@Override
	public void updateSbAccount(SbAccount sbAccount) {
    
		Iterator iterator = sbAccountList.iterator();
		
		
		while(iterator.hasNext()){
			
			SbAccount pe =(SbAccount)iterator.next();
			
			    if(pe.getAccountNo()==sbAccount.getAccountNo()){
				
				pe.setAccountHolderName(sbAccount.getAccountHolderName());
				pe.setRate(sbAccount.getRate());
				pe.setTime(sbAccount.getTime());
				pe.setBalanceAmount(sbAccount.getBalanceAmount());
				
				
				
			}
			
			
		}
		
	}

}
