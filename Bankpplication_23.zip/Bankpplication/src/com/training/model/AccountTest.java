package com.training.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.training.Exception.InsufficiantMoneyException;

class AccountTest {

	@Test
	void testWithDrawAmount() {
		int expected = 8000;
		Account a = new Account();
		try {
			a.withDrawAmount(2000);
		} catch (InsufficiantMoneyException e) {
		
			e.printStackTrace();
		}
		float actual = a.getBalanceAmount();
		assertEquals(expected,actual);
		
		
		
	}

}
