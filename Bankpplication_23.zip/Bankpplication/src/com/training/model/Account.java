/**
  * Class name: Account
 * 
 * Description: this is a base class for Account sub type
 * 
 * Date:30/09/2020
 * 
 */


package com.training.model;

import com.training.Exception.InsufficiantMoneyException;
import com.training.util.Icalculator;
import  com.training.Exception.*;
/**
 * this is a base class for Account sub type
 * @author sanga
 *
 */
public class Account {
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + accountNo;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Account other = (Account) obj;
		if (accountNo != other.accountNo)
			return false;
		return true;
	}

	private int  accountNo;
	protected String accountHolderName;
	protected float balanceAmount;
	
	public int getAccountNo() {
		return accountNo;
	}
	
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	
	public String getAccountHolderName() {
		return accountHolderName;
	}
	
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	
	public float getBalanceAmount() {
		return balanceAmount;
	}
	
	
    public void setBalanceAmount(float balanceAmount) {
		this.balanceAmount = balanceAmount;
	}

	public void  withDrawAmount( float amountToWithdraw) throws InsufficiantMoneyException {
    	
    if (amountToWithdraw > this.balanceAmount) {
			
			throw new InsufficiantMoneyException(amountToWithdraw);
		}
		
    else {
		this.balanceAmount =balanceAmount -amountToWithdraw;
		System.out.println("Available balance in your savings account =" +this.balanceAmount);
	}
	}
	    
	  public void calculateInterest(Icalculator calculator) {
			
		 System.out.println("inside base class");
	  }
	  
	  @Override
		public String toString() {
			return "Account [accountNumber=" +  accountNo + ", accountHolderName=" + accountHolderName + "]";
		}
	    
	  /* constructor with non-parameters  */
	  public Account() {
		 super();
	  }
	  
	  /* constructor with  parameters */
	  public Account(int accountNo,String accountHolderName,float balanceAmount) {
		  super();
		  this.accountNo =accountNo;
		  this.accountHolderName=accountHolderName;
		  this.balanceAmount = balanceAmount;
	  }
	  
	  
	    
	   
	
}
