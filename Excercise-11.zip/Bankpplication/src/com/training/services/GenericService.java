package com.training.services;

import com.training.model.Account;
import com.training.model.CurrentAccount;
import com.training.model.FdAccount;
import com.training.model.LoanAccount;
import com.training.model.SbAccount;
import com.training.util.InterestCalculator;

public class GenericService {

	public static void main(String[] args) {

		// calling the non-parameterised constructers

		System.out.println("called  non-parameterised comstructors");
		System.out.println("******************************************************************");

		FdAccount fdacc1 = new FdAccount();

		fdacc1.setAccountNo("App123456634");
		fdacc1.setIfscCode("APP000561");
		fdacc1.setAccountHolderName("Priyanka");

		fdacc1.withDrawAmount(2000);
		fdacc1.autoRenewable(2);
		fdacc1.setRate(.5f);
		fdacc1.setTenure(1);

		CurrentAccount cac = new CurrentAccount();

		cac.setAccountNo("App123456634");
		cac.setIfscCode("APP000561");
		cac.setAccountHolderName("Priyanka");
		cac.setOverDraftLimit(100000);
		cac.isLimitExceed(70000);

		LoanAccount lac = new LoanAccount();

		lac.setAccountNo("App123456632");
		lac.setIfscCode("APP000561");
		lac.setAccountHolderName("Priya");
		lac.setEmi(1295);
		lac.setLoanOutstanding(2000);
		lac.setTernure(2);

		SbAccount scac = new SbAccount();

		scac.setAccountNo("App123456634");
		scac.setIfscCode("APP000561");
		scac.setAccountHolderName("Priyanka");
		scac.setRate(0.7f);

		System.out.println();
		System.out.println("called parameterised comstructors");
		System.out.println("******************************************************************");

		// calling the parameterised constructers

		FdAccount fdacc = new FdAccount("sp123456", "Priyanka", 10000, 2, .5f);
		CurrentAccount cac1 = new CurrentAccount("SBI12345", "Lucky", 100000, 200000);
		LoanAccount lac1 = new LoanAccount("sp123456", "Priyanka", 10000, 2145, 2000, 3);
		SbAccount scac1 = new SbAccount("sp123456", "Priyanka", 10000, 0.7f, 3);

	}
}
