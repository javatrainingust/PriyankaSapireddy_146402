/*
 * Classname: SbAccount
 * 
 * Description: sub class that extends Account 
 * 
 * Date: 30/09/2020
 * 
 * 
 */

package com.training.model;

import com.training.util.Icalculator;

public class SbAccount extends Account {

	private float rate;
	private int time;

	/* creating non-parameterized and parameterized constructors */
	public SbAccount() {

		System.out.println("Inside SbAccount non-paramenterised constructor");
	}

	public SbAccount(String accountNo, String accountHolderName, float balanceAmount, float rate, int time) {

		super(accountNo, accountHolderName, balanceAmount);
		System.out.println("Inside SbAccount paramenterised constructor");
	}

	public float getRate() {
		return rate;
	}

	public void setRate(float rate) {
		this.rate = rate;
	}

	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}

	public void calculateInterest(Icalculator calculator) {
		
		/* Icalculator is an interface that implemented by InterestCalculator that calculate interest */
		float interesrt = calculator.calculateInterest(this.getBalanceAmount(), this.rate);
		System.out.println("your SBAccount will have RS " + interesrt + " as interest  with rate " + this.rate);

	}

}
