/**
 * Class: SbAccountDAOSQLImpl
 * 
 * Description: SbAccountDAOSQLImpl class used as Repository and implements SbAccountDAO interface 
 * 
 * Date : 23/10/2020
 */

package com.training.dataaccess;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.training.model.SbAccount;
/**
 * SbAccountDAOSQLImpl class used as Repository and implements SbAccountDAO interface 
 * @author sanga
 *
 */
@Repository
public class SbAccountDAOSQLImpl implements SbAccountDAO {

	private DataSource dataSource;

	private JdbcTemplate jdbcTemplateObject;
		
		@Autowired
		public void setDataSource(DataSource dataSource) {
			this.dataSource = dataSource;
			jdbcTemplateObject = new JdbcTemplate(dataSource);
		}
/**
 * getAllSbAccountdetails method is uesd to get all eaccouts 
 */
	public List<SbAccount> getAllSbAccountdetails() {
		
		String SQL = "SELECT * FROM banking.sbaccount";
		
	      List <SbAccount> employees= jdbcTemplateObject.query(SQL, new SbaccountMapper());
		
		return employees;
		
	}
/**
 * getSbAccountByAccountNumber method is ued to access account by using accountNo
 */
	public SbAccount getSbAccountByAccountNumber(int accountNo) {
		
		String sql = "select * from banking.sbaccount where accountNo= ?";
		 
		SbAccount employee = (SbAccount) jdbcTemplateObject.queryForObject(
                sql, new Object[] { accountNo }, new SbaccountMapper());
      
       return 	employee;	
	}
/**
 * deleteSbAccount method is used to deleteSbAccount 
 */
	public void deleteSbAccount(int accountNo) {
		 String query="delete from banking.sbaccount where accountNo ='"+accountNo+"' ";  
		 jdbcTemplateObject.update(query);  

	}
/**
 *  addSbAccount method is used to addSbAccount 
 */
	public boolean addSbAccount(SbAccount sbAccount) {
		String sql = "Insert into  banking.sbaccount" +
		 "(accountNo,accountHolderName,balanceAmount,rate,time) values(?,?,?,?,?)";
		

	  jdbcTemplateObject.update(sql, new Object[] { sbAccount.getAccountNo(),
				sbAccount.getAccountHolderName(), sbAccount.getBalanceAmount(),sbAccount.getRate(),sbAccount.getTime()
	        });
		return true;
	}
/***
 * updateSbAccount is used to updateSbAccount
 */
	public void updateSbAccount(SbAccount sbAccount) {
		
		String query="update banking.sbaccount set accountNo'"+ sbAccount.getAccountNo()+"',"
				+ " accountHolderName ='"+sbAccount.getAccountHolderName()+"' where accountNo ='"+sbAccount.getAccountNo()+"' ";  
	    jdbcTemplateObject.update(query);  


	}

}
