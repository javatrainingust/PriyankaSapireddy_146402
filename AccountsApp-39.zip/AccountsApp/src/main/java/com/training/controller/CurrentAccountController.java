/**
 * Class Name: SbAccountController
 * 
 * Description: Class which is used give the http request to server by using @Controller and @RequestMapping
 * 
 * Date:15/10/2020
 */
package com.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.training.model.CurrentAccount;
import com.training.model.FdAccount;
import com.training.model.SbAccount;
import com.training.service.CurrentAccountService;
import com.training.service.FdAccountService;
/**
 *  Class which is used give the http request to server by using @Controller and @RequestMapping
 * 
 * @author sanga
 *
 */
@RestController
public class CurrentAccountController {

	@Autowired
	private CurrentAccountService service;
	
	/**
	 * getAllCurrentAccounts method to get all Accounts 
	 * @param model
	 * @return
	 */
	
	@RequestMapping(value="/cuaccounts",method=RequestMethod.GET) 
	public List<CurrentAccount>  getAllCurrentAccounts(){
		
		List<CurrentAccount> employeeList = service.getAllCurrentAccounttdetails();
		
	
		
		
		return employeeList ;
		

}
	
	/**
	 * addEmployee  method to addCurrentAccount
	 * @param pe 
	 * @return redirect:/caccounts
	 */

	@RequestMapping(value="/cuaccounts",method=RequestMethod.POST) 
	public CurrentAccount addEmployee(@RequestBody CurrentAccount pe) {
		
		
		service.addCurrentAccount(pe);
		
		return pe;
		}
	
	@RequestMapping(value="/cuaccounts/{accountNo}",method=RequestMethod.PUT)
	public CurrentAccount updateCurrentAccounts(@PathVariable  int  accountNo,@RequestBody CurrentAccount pe) {
		
		
		service.updateCurrentAccount(pe);
	  		
		return pe;
		
		
	}
	/**
	 * getaccount method to getCurrentAccountByAccountNumber
	 * @param accountNo
	 * @param model
	 * @return viewcurrentAccount
	 */
	@RequestMapping(value="/cuaccounts/{accountNo}",method=RequestMethod.GET) 
	public CurrentAccount getaccount(@PathVariable int accountNo) {
		
		
		CurrentAccount pe = service.getCurrentAccountByAccountNumber(accountNo);
		return pe;
		
		
	}
	
	/**getAllCurrentAccountsByName METHOD is used for getAllCurrentAccountSortedByNames
	 * 
	 * @param model
	 * @return currentAccountList
	 */
@RequestMapping("/sortCurrentAccounyByName")
	
	public String getAllCurrentAccountsByName(Model model){
		
		System.out.println("Inside controller getAllCurrentAccounts ");
		
		List<CurrentAccount> employeeList = service.getAllCurrentAccountSortedByNames();
		
		model.addAttribute("caccounts",employeeList );
		
		
		return "currentAccountList";
		

}
/**
 * getAllCurrentAccountsByBalance   METHOD is used for  getAllCurrentAccountSortedByOverDraftLimit
 * @param model
 * @return currentAccountList
 */

@RequestMapping("/sortCurrentAccountByOverdraftLimit")

public String getAllCurrentAccountsByBalance(Model model){
	
	System.out.println("Inside controller getAllCurrentAccounts ");
	
	List<CurrentAccount> employeeList = service.getAllCurrentAccountSortedByOverDraftLimit();
	
	model.addAttribute("caccounts",employeeList );
	
	
	return "currentAccountList";
	

}
	/**
	 * deletecurrentAccount method to deleteCurrentAccount
	 * @param accountNo
	 * @param model
	 * @return "redirect:/caccounts"
	 */
@RequestMapping(value="/cuaccounts/{accountNo}",method=RequestMethod.DELETE) 
	public void deletecurrentAccount(@PathVariable int accountNo) {
	
		
     service.deleteCurrentAccount(accountNo);
		
		
		
		
   
		
		
	}
}
